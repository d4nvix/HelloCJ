@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0HelloCJ.ps1" goto missing
if not exist "%~dp0config.json" goto missing
if not exist "%~dp0.tools\StartGuest.ps1" goto missing
if not exist "%~dp0.tools\GuestReady.ps1" goto missing
echo GTA will request administrator rights. Approve the Windows UAC prompt.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0HelloCJ.ps1" -Action Play
if errorlevel 1 (
  echo Launch needs attention. The error above shows which part failed.
  echo Details: logs\last-error.txt and logs\guest-launch-error.txt.
  pause
  exit /b 1
)
exit /b 0
:missing
echo Incomplete HelloCJ package. Extract the whole folder, not only play.bat.
pause
exit /b 1
