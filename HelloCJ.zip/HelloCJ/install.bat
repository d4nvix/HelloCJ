@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0HelloCJ.ps1" goto missing
if not exist "%~dp0.tools\ConfigurePaths.ps1" goto missing
if not exist "%~dp0.tools\FinishBatInstall.ps1" goto missing
if not exist "%~dp0.tools\files-manifest.json" goto missing
powershell.exe -NoProfile -Command "$p=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent()); if($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){exit 0}else{exit 1}"
if errorlevel 1 goto needadmin
echo Administrator rights verified.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0.tools\ConfigurePaths.ps1"
if errorlevel 1 goto failed
echo Preparing installation. Both games must be closed; idle mod bridge is stopped automatically.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0HelloCJ.ps1" -Action PrepareBat
if errorlevel 1 goto failed
echo Backing up and copying mod files...
for /f "usebackq tokens=1-4 delims=|" %%A in ("%~dp0staging\copy-plan.txt") do (
  if exist "%%B\%%C" (
    robocopy "%%B\." "%%D\." "%%C" /COPY:DAT /R:0 /W:0 /NJH /NJS /NP
    if errorlevel 8 goto failed
  )
  robocopy "%%A\." "%%B\." "%%C" /COPY:DAT /IS /IT /R:0 /W:0 /NJH /NJS /NP
  if errorlevel 8 goto failed
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0.tools\FinishBatInstall.ps1"
if errorlevel 1 goto failed
echo Installed. Use play.bat to launch.
pause
exit /b 0
:needadmin
echo Administrator rights are required. No installation changes were made.
echo Right-click install.bat and select Run as administrator.
pause
exit /b 1
:failed
echo Installation stopped. Check the error above. Backups are in backups.
echo For a protected game folder, run install.bat as administrator.
pause
exit /b 1
:missing
echo Incomplete HelloCJ package. Extract all files and the .tools folder before installing.
pause
exit /b 1
