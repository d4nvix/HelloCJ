param([Parameter(Mandatory=$true)][string]$GtaDir,[Parameter(Mandatory=$true)][string]$HostExe)
$ErrorActionPreference='Stop'
try {
    . (Join-Path $PSScriptRoot 'ProcessIdentity.ps1')
    $principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator rights required.'}
    $exe=Join-Path ([IO.Path]::GetFullPath($GtaDir)) 'gta_sa.exe'
    $hostPath=[IO.Path]::GetFullPath($HostExe)
    if(-not (Test-Path -LiteralPath $hostPath -PathType Leaf) -or $hostPath -match '[\r\n]'){throw 'Invalid Hello Neighbor executable.'}
    @('[HelloCJ]',('HostExe='+$hostPath)) | Set-Content -LiteralPath (Join-Path $GtaDir 'HelloCJ-launch.ini') -Encoding Default
    $games=@(Get-Process gta_sa -ErrorAction SilentlyContinue)
    if($games.Count -gt 1){throw 'Multiple GTA processes; no game changed.'}
    foreach($game in $games){if((Get-HelloCJProcessPath $game) -ne $exe){throw 'Different GTA installation is running; no game changed.'}}
    if(-not $games.Count){
        if(Test-Path -LiteralPath (Join-Path $GtaDir 'HelloCJAutoStart.asi')){
            Set-Content -LiteralPath (Join-Path $GtaDir 'HelloCJ-autostart.request') 'new-game'
        }
        Start-Process -FilePath $exe -WorkingDirectory $GtaDir -WindowStyle Hidden | Out-Null
    }elseif(Test-Path -LiteralPath (Join-Path $GtaDir 'HelloCJ-autostart.request')){
        # A failed/retried launch may leave a pending request older than the ASI lease.
        Set-Content -LiteralPath (Join-Path $GtaDir 'HelloCJ-autostart.request') 'new-game'
    }
    & (Join-Path $PSScriptRoot 'GuestWindow.ps1') -GtaDir $GtaDir -WaitSeconds 45 | Out-Null
    exit 0
} catch {
    $logs=Join-Path (Split-Path $PSScriptRoot) 'logs'
    New-Item -ItemType Directory -Path $logs -Force | Out-Null
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $logs 'guest-launch-error.txt')
    exit 1
}
