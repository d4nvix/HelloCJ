param([string]$PackageRoot=(Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
try {
    $file=Join-Path $PackageRoot 'config.json'
    $config=if(Test-Path -LiteralPath $file){Get-Content -LiteralPath $file -Raw | ConvertFrom-Json}else{[pscustomobject]@{}}
    function Read-GameFolder([string]$Label,[string]$Current,[string]$Executable){
        while($true){
            $prompt=if($Current){"$Label folder [$Current] (Enter keeps it)"}else{"$Label folder"}
            $answer=Read-Host $prompt
            $candidate=if([string]::IsNullOrWhiteSpace($answer)){$Current}else{$answer.Trim().Trim('"')}
            try {
                if(-not $candidate -or -not [IO.Path]::IsPathRooted($candidate)){throw 'Enter a full folder path.'}
                $path=[IO.Path]::GetFullPath($candidate).TrimEnd('\')
                if(-not(Test-Path -LiteralPath (Join-Path $path $Executable) -PathType Leaf)){throw "Cannot find $Executable in this folder."}
                return $path
            } catch {Write-Host $_.Exception.Message -ForegroundColor Yellow}
        }
    }
    $gta=Read-GameFolder 'GTA San Andreas' $config.gtaDir 'gta_sa.exe'
    $hn=Read-GameFolder 'Hello Neighbor' $config.helloNeighborDir 'HelloNeighbor\Binaries\Win64\HelloNeighbor-Win64-Shipping.exe'
    $config | Add-Member -NotePropertyName gtaDir -NotePropertyValue $gta -Force
    $config | Add-Member -NotePropertyName helloNeighborDir -NotePropertyValue $hn -Force
    $config | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $file -Encoding UTF8
    Write-Host 'Game folders saved.'
} catch {Write-Error $_; exit 1}
