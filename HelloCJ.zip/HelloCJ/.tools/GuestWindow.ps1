param([string]$GtaDir='D:\GTA\Grand Theft Auto San Andreas',[switch]$Show,[ValidateRange(0,60)][int]$WaitSeconds=0)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'ProcessIdentity.ps1')
if(-not ('SANeighborGuestWindow' -as [type])){
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class SANeighborGuestWindow {
 delegate bool EnumProc(IntPtr w,IntPtr p);
 [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback,IntPtr data);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr w,StringBuilder text,int size);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr w,out uint pid);
 [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr w,int command);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr w);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr w);
 public static IntPtr Find(uint pid) {
  IntPtr found=IntPtr.Zero;
  EnumWindows((w,p)=>{uint owner;GetWindowThreadProcessId(w,out owner);
   if(owner!=pid)return true;
   var title=new StringBuilder(512);GetWindowText(w,title,title.Capacity);
   if(!title.ToString().StartsWith("GTA: San Andreas",StringComparison.Ordinal))return true;
   found=w;return false;
  },IntPtr.Zero);return found;
 }
}
'@
}
$until=[DateTime]::UtcNow.AddSeconds($WaitSeconds)
do {
    $items=@(Get-Process -Name gta_sa -ErrorAction SilentlyContinue)
    if($items.Count -eq 0){
        if([DateTime]::UtcNow -ge $until){throw 'GTA process did not appear before the startup timeout; no window changed.'}
        Start-Sleep -Milliseconds 250
        continue
    }
    if($items.Count -ne 1){throw 'Expected exactly one verified GTA installation; no window changed.'}
    $image=Get-HelloCJProcessPath $items[0]
    if(-not $image){
        if([DateTime]::UtcNow -ge $until){throw 'Cannot read GTA process image path before startup timeout; no window changed.'}
        Start-Sleep -Milliseconds 250
        continue
    }
    if($image -ne (Join-Path $GtaDir 'gta_sa.exe')){throw 'Different GTA installation; no window changed.'}
    $game=$items[0]
    $window=[SANeighborGuestWindow]::Find($game.Id)
    if($window -ne [IntPtr]::Zero){break}
    if([DateTime]::UtcNow -ge $until){throw 'GTA game window unavailable; loader dialogs are not hidden.'}
    Start-Sleep -Milliseconds 250
} while($true)
if(-not $Show -and [SANeighborGuestWindow]::IsIconic($window)){
    [SANeighborGuestWindow]::ShowWindowAsync($window,4) | Out-Null
}
[SANeighborGuestWindow]::ShowWindowAsync($window, $(if($Show){4}else{0})) | Out-Null
$until=[DateTime]::UtcNow.AddSeconds(2)
do {
    $visible=[SANeighborGuestWindow]::IsWindowVisible($window)
    if($visible -eq [bool]$Show){break}
    Start-Sleep -Milliseconds 50
} while([DateTime]::UtcNow -lt $until)
if($visible -ne [bool]$Show){throw 'GTA did not acknowledge the requested window visibility.'}
[pscustomobject]@{pid=$game.Id;window=$window.ToInt64();hidden=-not $visible;minimized=[SANeighborGuestWindow]::IsIconic($window)}
