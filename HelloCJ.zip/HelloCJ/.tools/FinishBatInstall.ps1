$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
try {
    $config=Get-Content -LiteralPath (Join-Path $root 'config.json') -Raw | ConvertFrom-Json
    $gta=[IO.Path]::GetFullPath($config.gtaDir).TrimEnd('\')
    $bin=Join-Path ([IO.Path]::GetFullPath($config.helloNeighborDir)) 'HelloNeighbor\Binaries\Win64'
    $operations=Get-Content -LiteralPath (Join-Path $root 'staging\copy-plan.json') -Raw | ConvertFrom-Json
    foreach($op in $operations){
        $targetRoot=if($op.group -eq 'GTA'){$gta}else{$bin}
        $target=[IO.Path]::GetFullPath($op.target)
        if(-not $target.StartsWith($targetRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid copy target.'}
        if((Get-FileHash -LiteralPath $op.source).Hash -ne (Get-FileHash -LiteralPath $target).Hash){throw "Copy verification failed: $target"}
    }
    $skyRoot=Join-Path $gta 'modloader\SANeighborSky'
    $prefix='modloader\SANeighborSky\'
    @($operations | Where-Object {$_.group -eq 'GTA' -and $_.relative.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)} | ForEach-Object {
        @{path=$_.relative.Substring($prefix.Length);sha256=(Get-FileHash -LiteralPath $_.target).Hash}
    }) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $skyRoot 'SANeighbor-sky.json')
    $manifest=Join-Path $bin 'SANeighbor-host.json'
    $owned=@{}
    if(Test-Path -LiteralPath $manifest){
        $records=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
        foreach($entry in $records){$owned[$entry.path]=$entry.sha256}
    }
    foreach($op in $operations | Where-Object {$_.group -eq 'HN'}){$owned[$op.relative]=(Get-FileHash -LiteralPath $op.target).Hash}
    @($owned.Keys | ForEach-Object {@{path=$_;sha256=$owned[$_]}}) | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $manifest
    . (Join-Path $PSScriptRoot 'HostMode.ps1')
    Set-ExclusiveHostMode -Target $bin -Mode SANeighbor
    Write-Host 'Copied files verified and mod enabled.'
} catch {
    Write-Error $_
    exit 1
}
