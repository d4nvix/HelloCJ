function Test-HelloCJGuestReady {
    param([string]$Life,[string]$Player,[long]$Now)
    if([string]::IsNullOrWhiteSpace($Life) -or [string]::IsNullOrWhiteSpace($Player)){return $false}
    $l=@($Life.Trim() -split '\s+')
    $p=@($Player.Trim() -split '\s+')
    if($l.Count -ne 5 -or $p.Count -notin @(18,19)){return $false}
    $epoch=0L
    if($p.Count -eq 19 -and (-not [long]::TryParse($p[18],[ref]$epoch) -or $epoch -lt 0)){return $false}
    $stamp=0L;$playerStamp=0L;$seq=0L
    if(-not [long]::TryParse($l[1],[ref]$stamp) -or -not [long]::TryParse($p[1],[ref]$playerStamp) -or -not [long]::TryParse($p[2],[ref]$seq)){return $false}
    return $l[0] -eq '1' -and $l[2] -eq '0' -and $l[3] -eq '0' -and $l[4] -eq '1' -and $p[0] -eq '1' -and
        $stamp -le $Now -and $Now-$stamp -le 2 -and $playerStamp -le $Now -and $Now-$playerStamp -le 2 -and $seq -ge 0
}
function Wait-HelloCJGuestReady {
    param([string]$HostBin,[int]$TimeoutSeconds=180)
    $until=[DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    $lastSequence=$null;$stable=0
    do {
        try {
            $life=Get-Content -LiteralPath (Join-Path $HostBin 'sa_guest.life') -Raw -ErrorAction Stop
            $player=Get-Content -LiteralPath (Join-Path $HostBin 'sa_player.ready') -Raw -ErrorAction Stop
            $now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            if(Test-HelloCJGuestReady $life $player $now){
                $seq=($player.Trim() -split '\s+')[2]
                if($seq -ne $lastSequence){$stable++;$lastSequence=$seq}
                if($stable -ge 3){return}
            }else{$stable=0;$lastSequence=$null}
        }catch{$stable=0;$lastSequence=$null}
        Start-Sleep -Milliseconds 250
    }while([DateTime]::UtcNow -lt $until)
    throw 'GTA did not report loaded gameplay with completed fade within 180 seconds. Hello Neighbor was not started. Check GTA/new game and bridge logs.'
}
