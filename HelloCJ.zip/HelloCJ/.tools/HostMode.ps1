function Get-ExclusiveHostMods {
    param([string[]]$Lines, [ValidateSet('SANeighbor','HelloCraft')][string]$Mode)
    $enabled = if ($Mode -eq 'SANeighbor') { @('SARenderer','SANeighbor') } else { @('HnGfx','HnLink') }
    $seen = @{}
    $result = foreach ($line in $Lines) {
        if ($line -match '^\s*(SARenderer|SANeighbor|HnGfx|HnLink)\s*:') {
            $name = $Matches[1]
            if (-not $seen.ContainsKey($name)) {
                $seen[$name] = $true
                '{0} : {1}' -f $name, [int]($name -in $enabled)
            }
        } else { $line }
    }
    foreach ($name in $enabled) {
        if (-not $seen.ContainsKey($name)) { $result = @("$name : 1") + $result }
    }
    return $result
}

function Set-ExclusiveHostDlls {
    param([string]$Mods, [ValidateSet('SANeighbor','HelloCraft')][string]$Mode)
    $manifestPath = Join-Path (Split-Path -Parent (Split-Path -Parent $Mods)) 'SANeighbor-modes.json'
    $records = if (Test-Path -LiteralPath $manifestPath) { @(Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json) } else { @() }
    $active = if ($Mode -eq 'SANeighbor') { 'SARenderer' } else { 'HnGfx' }
    $operations = @()
    foreach ($mod in @('SARenderer','HnGfx')) {
        foreach ($name in @('main.dll',"$mod.dll")) {
            $relative = "$mod\dlls\$name"
            $live = Join-Path $Mods $relative
            $parked = "$live.disabled-by-SANeighbor"
            $hasLive = Test-Path -LiteralPath $live
            $hasParked = Test-Path -LiteralPath $parked
            if ($hasLive -and $hasParked) { throw "Both active and parked DLL exist: $relative. No DLLs changed." }
            if ($hasParked) {
                $entry = @($records | Where-Object { $_.path -eq $relative })
                if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath $parked).Hash -ne $entry[0].sha256) {
                    throw "Parked DLL has no matching ownership hash: $relative. No DLLs changed."
                }
                if ($mod -eq $active) { $operations += @{from=$parked;to=$live} }
            } elseif ($hasLive -and $mod -ne $active) {
                $hash = (Get-FileHash -LiteralPath $live).Hash
                $records = @($records | Where-Object { $_.path -ne $relative }) + @([pscustomobject]@{path=$relative;sha256=$hash})
                $operations += @{from=$live;to=$parked}
            }
        }
    }
    if ($operations.Count) {
        # UE4SS probes native DLLs before respecting mods.txt. Keep the inactive hook out of that probe.
        ConvertTo-Json -InputObject @($records) -Depth 4 | Set-Content -LiteralPath $manifestPath
        foreach ($operation in $operations) {
            Rename-Item -LiteralPath $operation.from -NewName (Split-Path -Leaf $operation.to)
        }
    }
}

function Set-ExclusiveHostMode {
    param([string]$Target, [ValidateSet('SANeighbor','HelloCraft')][string]$Mode)
    $process = Get-CimInstance Win32_Process -Filter "Name='HelloNeighbor-Win64-Shipping.exe'" |
        Where-Object { $_.ExecutablePath -eq (Join-Path $Target 'HelloNeighbor-Win64-Shipping.exe') }
    if ($process) { throw 'Close Hello Neighbor before selecting a host mod.' }
    $mods = Join-Path $Target 'ue4ss\Mods'
    $inactive = if ($Mode -eq 'SANeighbor') { @('HnGfx','HnLink') } else { @('SARenderer','SANeighbor') }
    foreach ($name in $inactive) {
        if (Test-Path -LiteralPath (Join-Path $mods "$name\enabled.txt")) {
            throw "$name has an enabled.txt override. Remove that override before switching; no files changed."
        }
    }
    $path = Join-Path $mods 'mods.txt'
    $lines = @(Get-Content -LiteralPath $path)
    $next = @(Get-ExclusiveHostMods -Lines $lines -Mode $Mode)
    Set-ExclusiveHostDlls -Mods $mods -Mode $Mode
    if (($lines -join "`n") -ne ($next -join "`n")) {
        $backup = "$path.before-mode-$(Get-Date -Format 'yyyyMMdd-HHmmss-ffff')"
        Copy-Item -LiteralPath $path -Destination $backup
        Set-Content -LiteralPath $path -Value $next
        Write-Host "Host mode: $Mode; previous mod list saved in $backup"
        $manifestPath = Join-Path $Target 'SANeighbor-host.json'
        if (Test-Path -LiteralPath $manifestPath) {
            $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
            $entry = $manifest | Where-Object { $_.path -eq 'ue4ss\Mods\mods.txt' }
            if ($entry) {
                $entry.sha256 = (Get-FileHash -LiteralPath $path).Hash
                $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath
            }
        }
    }
}
