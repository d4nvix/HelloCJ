param([Parameter(Mandatory=$true)][string]$GtaDir,[Parameter(Mandatory=$true)][string]$OutputPath)
$ErrorActionPreference='Stop'
$source=Join-Path $GtaDir 'data\gta.dat'
$encoding=[Text.Encoding]::GetEncoding(28591)
$lines=@([IO.File]::ReadAllLines($source,$encoding))
if(-not ($lines | Where-Object {$_ -match '^\s*IDE\s+'}) -or -not ($lines | Where-Object {$_ -match '^\s*IPL\s+'})){throw 'Unsupported gta.dat: IDE/IPL sections not found.'}
$lines=@($lines | Where-Object {$_ -notmatch '^\s*(IDE|COLFILE|IPL)\s+.*[\\/]saneighbor[\\/]'})
$result=New-Object 'System.Collections.Generic.List[string]'
$inserted=$false
foreach($line in $lines){
    if(-not $inserted -and $line -match '^\s*IPL\s+'){
        $result.Add('IDE DATA\MAPS\SANeighbor\saneighbor.ide')
        $result.Add('COLFILE 0 DATA\MAPS\SANeighbor\sa_skyfloor.col')
        $inserted=$true
    }
    $result.Add($line)
}
$result.Add('IPL DATA\MAPS\SANeighbor\saneighbor.ipl')
$output=[IO.Path]::GetFullPath($OutputPath)
if($output -eq [IO.Path]::GetFullPath($source)){throw 'Refusing to modify the base game gta.dat in place.'}
New-Item -ItemType Directory -Path (Split-Path $output) -Force | Out-Null
[IO.File]::WriteAllLines($output,$result,$encoding)
