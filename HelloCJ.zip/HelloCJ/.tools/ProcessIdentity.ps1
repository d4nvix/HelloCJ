if(-not ('HelloCJProcessIdentity' -as [type])){
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class HelloCJProcessIdentity {
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr process,uint flags,StringBuilder text,ref int size);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr process);
 public static string Path(int pid) {
  var process=OpenProcess(0x1000,false,pid);
  if(process==IntPtr.Zero)return null;
  try {int size=32768;var text=new StringBuilder(size);return QueryFullProcessImageName(process,0,text,ref size)?text.ToString():null;}
  finally {CloseHandle(process);}
 }
}
'@
}
function Get-HelloCJProcessPath($Process){
    try {if($Process.Path){return $Process.Path}} catch {}
    if($Process -is [Diagnostics.Process]){return [HelloCJProcessIdentity]::Path($Process.Id)}
    return $null
}
