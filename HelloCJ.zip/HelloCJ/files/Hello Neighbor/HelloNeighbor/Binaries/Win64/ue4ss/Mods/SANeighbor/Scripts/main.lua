local ticks, queued, failures = 0, false, 0
local offsets, published, pawnAddress = nil, nil, nil
local enabled = true
local cameraSync = false
local cjMode, ownsView = false, false
local cameraActor, currentPc, currentPawn, originalView = nil, nil, nil, nil
local lastPose = {0, 0, 0}
local moveOwned, savedMovementMode, moveOrigin = false, 1, nil
local lastControlledHost=nil
local correction, sentCorrection = {X=0,Y=0,Z=0}, 0
local nativeSequence = nil
local movementEpoch = 0
local frameTargetApplied = false
local cameraDistance = 320
local savedCapsule, capsuleVehicle = nil, false
local toggleCJ
local groundSample,groundTick=nil,-100
local groundProbePosition=nil
local groundSlopeX,groundSlopeY,groundPlaneTick=0,0,-100
local mantleUntil,mantleBase,jumpWasDown=-100,nil,false
local writes={}
local labSerial=nil
local attachedHidden={}
local loggedSupport={}
local lastToggleSerial=nil
local lastGuestReply,lastGuestTick=nil,-100
local groundContact=nil
local nativeCameraReply,nativeCameraTick=nil,-100
local nativeCameraFrame,nativeCameraPid=nil,nil
local lookOwned=false
local menuTick,menuVisible=-100,false
local hiddenCursor=nil
local deathArmed,deathAt,deathPawn=false,nil,nil
local awaitingRespawn=false
local nativeFadeOwned=false
local dayMinutes=nil
local write
local hadPlaySession=false
local lastPlayStamp=nil
local function playSessionActive()
    local file=io.open("sa_play.session","r")
    if file then
        local text=file:read("*a") file:close()
        if text:match("^0%s*$") then lastPlayStamp=nil return false end
        local stamp=tonumber(text:match("^1%s+(%d+)%s*$"))
        if stamp then lastPlayStamp=stamp end
    end
    return lastPlayStamp and lastPlayStamp<=os.time() and os.time()-lastPlayStamp<=2 or false
end
local function hostClockTick(pc)
    if ticks%30~=0 then return end
    local ok,err=pcall(function()
        if not dayMinutes then
            local values,notes={},{}
            local enum=StaticFindObject("/Script/HelloNeighbor.EDayMode")
            enum:ForEachName(function(name,value)
                local text=name:ToString()
                notes[#notes+1]=text.."="..tostring(value)
                local key=(text:match("([^:]+)$") or text):lower()
                if key:find("morning",1,true) then values[value]=480
                elseif key:find("night",1,true) then values[value]=0
                elseif key:find("evening",1,true) or key:find("sunset",1,true) then values[value]=1080
                elseif key:find("noon",1,true) or key:match("day$") then values[value]=720 end
            end)
            dayMinutes=values
            write("sa_host.clock_modes",table.concat(notes,"\n"))
        end
        local gs=StaticFindObject("/Script/Engine.Default__GameplayStatics")
        local mode=gs:GetGameMode(pc):GetDayMode()
        local minute=dayMinutes[mode]
        if not minute then error("Unsupported Hello Neighbor day mode: "..tostring(mode)) end
        write("sa_host.clock",string.format("1 %d %d %d\n",ticks,minute,mode))
    end)
    if not ok then
        write("sa_host.clock","0\n") write("sa_host.clock_error",tostring(err))
    end
end
local function hostMenuVisible(pc,force)
    if not force and ticks-menuTick<8 then return menuVisible end
    menuTick=ticks
    local ok,found=pcall(function()
        local lib=StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        local class=StaticFindObject("/Script/UMG.UserWidget")
        if not lib or not class then return false end
        local widgets={}
        lib:GetAllWidgetsOfClass(pc,widgets,class,true)
        for _,widget in ipairs(widgets) do
            local name=widget:GetFullName():lower()
            if (name:find("menu",1,true) or name:find("settings",1,true) or name:find("options",1,true)) and
               widget:IsInViewport() and widget:IsVisible() then return true end
        end
        return false
    end)
    menuVisible=ok and found==true
    return menuVisible
end
do
    local f=io.open("sa_toggle.request","r")
    if f then lastToggleSerial=tonumber(f:read("*a")) f:close() end
end

write=function(path, text)
    if writes[path]==text then return end
    local f = io.open(path, "w")
    if f then f:write(text) f:close() writes[path]=text end
end
local function valid(object)
    if object == nil then return false end
    local ok, name = pcall(function() return object:GetFullName() end)
    return ok and type(name)=="string" and name ~= "" and not name:find("^None")
end
local function unwrap(object)
    if object~=nil and not valid(object) then
        for _,method in ipairs({"get","Get"}) do
            local ok,value=pcall(function() return object[method](object) end)
            if ok and value~=nil and value~=object then return value end
        end
    end
    return object
end
local barrierStates,lastBarrierScan={},-1000
local function actorsOfClass(context,path)
    local class=StaticFindObject(path)
    if not valid(class) or class:GetFullName()~="Class "..path then return {} end
    local out={}
    ForEachUObject(function(object)
        if object:IsA(class) and not object:HasAnyFlags(0x18010) then out[#out+1]=object end
    end)
    return out
end
local function restoreBarriers()
    for _,entry in pairs(barrierStates) do
        if valid(entry.actor) then pcall(function()
            if not entry.actor:GetActorEnableCollision() then entry.actor:SetActorEnableCollision(entry.collision) end
        end) end
    end
    barrierStates={} lastBarrierScan=-1000
end
local function barrierTick(active,pawn)
    if not active then if next(barrierStates) then restoreBarriers() end return end
    if ticks-lastBarrierScan<120 then return end
    lastBarrierScan=ticks
    local count=0
    local class=StaticFindObject("/Script/Engine.BlockingVolume")
    if not valid(class) or class:GetFullName()~="Class /Script/Engine.BlockingVolume" then return end
    for _,candidate in ipairs(FindAllOf("BlockingVolume") or {}) do
        local actor=unwrap(candidate)
        if valid(actor) and actor:IsA(class) then pcall(function()
            local address=actor:GetAddress()
            if not barrierStates[address] then
                barrierStates[address]={actor=actor,collision=actor:GetActorEnableCollision()}
            end
            actor:SetActorEnableCollision(false)
            count=count+1
        end) end
    end
    write("sa_host.barriers",tostring(count))
end
local function ownActors(pawn)
    local ignored={pawn}
    pcall(function()
        local out={}
        local result=pawn:GetAttachedActors(out)
        for _,entry in ipairs(type(result)=="table" and result or out) do
            local actor=unwrap(entry)
            if valid(actor) then ignored[#ignored+1]=actor end
        end
    end)
    pcall(function()
        local item=unwrap(pawn:GetHoldingItem())
        if valid(item) then ignored[#ignored+1]=item end
    end)
    return ignored
end
local function nativeClass(object,path)
    if not valid(object) then return nil end
    local class=object:GetClass()
    for depth=1,16 do
        if not valid(class) then return nil end
        if class:GetFullName()=="Class "..path then return class end
        class=class:GetSuperStruct()
    end
end
local function nativeSignature(class,name,expected)
    local matched=false
    class:ForEachFunction(function(fn)
        if fn:GetFName():ToString()~=name then return end
        local seen,good={},true
        fn:ForEachProperty(function(prop)
            local key=prop:GetFName():ToString()
            if seen[key] or expected[key]~=prop:GetClass():GetFName():ToString() then good=false end
            seen[key]=true
        end)
        for key in pairs(expected) do if not seen[key] then good=false end end
        matched=good
    end)
    return matched
end
local neighborHits={}
local function nativeNeighborShot(component,pawn)
    local owner=unwrap(component:GetOwner())
    local class=nativeClass(owner,"/Script/HelloNeighbor.Sosed")
    if not class or not nativeClass(pawn,"/Script/HelloNeighbor.Human") or
       not nativeSignature(class,"OnShotGun",{Human="ObjectProperty"}) or
       not nativeSignature(class,"MixerFall",{ReturnValue="BoolProperty"}) then return false end
    local gs=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    local now=gs:GetRealTimeSeconds(pawn)
    local address=owner:GetAddress()
    local last=neighborHits[address]
    if last and now>=last and now-last<.3 then return true end
    local accepted=owner:MixerFall()
    if accepted==true then owner:OnShotGun(pawn) end
    neighborHits[address]=now
    local behavior="unknown"
    if accepted==true then pcall(function() behavior=owner:GetBehavior():GetFullName() end) end
    write("sa_host.neighbor_hit",accepted==true and ("MixerFall accepted; OnShotGun dispatched; behavior="..behavior) or "MixerFall declined by native story/busy guard")
    return true
end
local windowDebris={}
local windowShotCollision,windowCollisionScanned={},false
local function restoreWindowShotCollision()
    for _,entry in pairs(windowShotCollision) do pcall(function()
        if valid(entry.mesh) and entry.mesh:GetCollisionResponseToChannel(3)==2 then
            entry.mesh:SetCollisionResponseToChannel(3,entry.response)
        end
    end) end
    windowShotCollision={} windowCollisionScanned=false
end
local function registerWindowShotCollision(actor)
    if not nativeClass(actor,"/Script/HelloNeighbor.Window") then return end
    for pane=1,3 do pcall(function()
        local mesh=unwrap(actor["GlassMesh"..pane])
        if not valid(mesh) or actor["bCrashed"..pane] or mesh:GetCollisionEnabled()==0 then return end
        local address=mesh:GetAddress()
        if not windowShotCollision[address] then
            local response=mesh:GetCollisionResponseToChannel(3)
            if response~=0 and response~=1 and response~=2 then return end
            windowShotCollision[address]={mesh=mesh,response=response}
        end
        mesh:SetCollisionResponseToChannel(3,2)
    end) end
end
local function windowCollisionTick(active)
    if not active then
        if windowCollisionScanned then restoreWindowShotCollision() end
        return
    end
    if windowCollisionScanned then return end
    local ok,err=pcall(function()
        for _,actor in ipairs(actorsOfClass(currentPawn,"/Script/HelloNeighbor.Window")) do registerWindowShotCollision(actor) end
    end)
    windowCollisionScanned=ok
    write("sa_host.window_collision",ok and "enabled" or tostring(err))
end
local function nativeWindowFracture(pc,component,point,direction,impulse)
    local owner=unwrap(component:GetOwner())
    if not nativeClass(owner,"/Script/HelloNeighbor.Window") then return false end
    local pane=nil
    for index=1,3 do
        local ok,mesh=pcall(function() return unwrap(owner["GlassMesh"..index]) end)
        if ok and valid(mesh) and mesh:GetAddress()==component:GetAddress() then pane=index break end
    end
    if not pane or owner["bCrashed"..pane]==true then return false end
    local asset=unwrap(owner.GlassDestructibleMesh)
    if not valid(asset) then return false end
    local gs=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    local now=gs:GetRealTimeSeconds(pc)
    for index=#windowDebris,1,-1 do if windowDebris[index]<=now then table.remove(windowDebris,index) end end
    if #windowDebris>=12 then return false end
    local cls=StaticFindObject("/Script/Engine.DestructibleActor")
    if not valid(cls) or cls:GetFullName()~="Class /Script/Engine.DestructibleActor" then
        cls=StaticFindObject("/Script/ApexDestruction.DestructibleActor")
        if not valid(cls) or cls:GetFullName()~="Class /Script/ApexDestruction.DestructibleActor" then return false end
    end
    local actor=nil
    local oldVisible,oldCollision,oldBroken=component:IsVisible(),component:GetCollisionEnabled(),owner["bCrashed"..pane]
    local changed=false
    local ok,err=pcall(function()
        local xf=component:K2_GetComponentToWorld()
        actor=gs:BeginDeferredActorSpawnFromClass(pc,cls,xf,1,nil)
        if not valid(actor) then error("Window debris actor unavailable") end
        gs:FinishSpawningActor(actor,xf)
        local debris=unwrap(actor.DestructibleComponent)
        if not valid(debris) then error("Window debris component unavailable") end
        local class=nativeClass(debris,"/Script/Engine.DestructibleComponent") or nativeClass(debris,"/Script/ApexDestruction.DestructibleComponent")
        if not class or not nativeSignature(class,"SetDestructibleMesh",{NewMesh="ObjectProperty"}) or
           not nativeSignature(class,"ApplyDamage",{DamageAmount="FloatProperty",HitLocation="StructProperty",ImpulseDir="StructProperty",ImpulseStrength="FloatProperty"}) then
            error("Window fracture signature mismatch")
        end
        debris:SetDestructibleMesh(asset)
        local life=tonumber(owner.m_fLifeTimeDestructibleMesh) or 4
        life=math.max(1,math.min(8,life))
        actor:SetLifeSpan(life)
        debris:ApplyDamage(100,point,direction,impulse)
        changed=true
        component:SetVisibility(false,false)
        component:SetCollisionEnabled(0)
        owner["bCrashed"..pane]=true
        pcall(function() write("sa_host.window_hit",owner:GetFullName().." pane="..pane.." broken="..tostring(owner["bCrashed"..pane]).." collision="..tostring(component:GetCollisionEnabled())) end)
        windowDebris[#windowDebris+1]=now+life
    end)
    if not ok then
        if changed then
            pcall(function() component:SetVisibility(oldVisible,false) end)
            pcall(function() component:SetCollisionEnabled(oldCollision) end)
            pcall(function() owner["bCrashed"..pane]=oldBroken end)
        end
        if valid(actor) then pcall(function() actor:K2_DestroyActor() end) end
        write("sa_host.glass_error",tostring(err))
    end
    return ok
end
local shotPid,shotSerial,shotClass=nil,0,nil
-- Quarantined after a live first-shot crash; never spawn native item proxies
-- until their Blueprint lifecycle has been verified in this exact game build.
local nativeImpactProxiesEnabled=false
local shotExpiries={}
local function impactProfile(weapon)
    return weapon and weapon>=25 and weapon<=27 and 900 or 90
end
local function physicalImpulse(component,weapon,blast)
    local ok,mass=pcall(function() return component:GetMass() end)
    local fallback=blast and 6000 or impactProfile(weapon)
    if not ok or type(mass)~="number" or mass~=mass or mass<=0 then return fallback end
    local speed=blast and 1800 or weapon and weapon>=25 and weapon<=27 and 650 or 120
    return math.min(blast and 180000 or 60000,math.max(fallback,mass*speed))
end
local function simulatedBody(component)
    if component:IsSimulatingPhysics(FName("None")) then return component end
    local owner=unwrap(component:GetOwner())
    if valid(owner) then
        local root=unwrap(owner:K2_GetRootComponent())
        if valid(root) and root:IsSimulatingPhysics(FName("None")) then return root end
    end
end
local function resolveImpactComponent(lib,pc,pawn,point)
    if not point then return nil end
    for _,axis in ipairs({"X","Y","Z"}) do
        local value=point[axis]
        if type(value)~="number" or value~=value or math.abs(value)>1e8 then return nil end
    end
    local out={}
    lib:SphereOverlapComponents(pc,point,4,{0,1,2,3,4,5,6,7},nil,ownActors(pawn),out)
    local debug={string.format("impact %.3f %.3f %.3f candidates %d",point.X,point.Y,point.Z,#out)}
    local seen,best,distance,ambiguous={},nil,math.huge,false
    for index,entry in ipairs(out) do
        if index>32 then return nil end
        local checked,why=pcall(function()
            local component=unwrap(entry)
            if not valid(component) then return end
            local address=component:GetAddress()
            if seen[address] then return end
            seen[address]=true
            if component:GetCollisionResponseToChannel(3)~=2 then return end
            local closest={}
            local d=component:GetClosestPointOnCollision(point,closest,FName("None"))
            debug[#debug+1]=component:GetFullName().." distance="..tostring(d)
            if type(d)~="number" or d~=d or d<0 or d>.75 then return end
            if d+.05<distance then best,distance,ambiguous=component,d,false
            elseif math.abs(d-distance)<=.05 then ambiguous=true end
        end)
        if not checked then debug[#debug+1]=tostring(why) end
    end
    write("sa_host.hit_debug",table.concat(debug,"\n"))
    return not ambiguous and best or nil
end
local function traceImpact(pc,pawn,origin,finish)
    local lib=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local color={R=0,G=0,B=0,A=0}
    local hit,nearest=nil,math.huge
    local ignored=ownActors(pawn)
    -- Some panes/props expose simple collision only. Keep the nearest blocker
    -- across both representations; never prefer glass over an intervening wall.
    for _,complex in ipairs({true,false}) do
        local candidate={}
        local blocked=lib:LineTraceSingle(pc,origin,finish,0,complex,ignored,0,candidate,true,color,color,0)
        if type(blocked)~="boolean" then error("Unsupported trace result") end
        if blocked then
            local point=candidate.ImpactPoint
            if not point then error("Missing blocking impact point") end
            local distance=0
            for _,axis in ipairs({"X","Y","Z"}) do
                local value=point[axis]
                if type(value)~="number" or value~=value or math.abs(value)>1e8 then error("Invalid blocking impact point") end
                distance=distance+(value-origin[axis])^2
            end
            if distance<nearest then hit,nearest=candidate,distance end
        end
    end
    if not hit then return nil end
    hit.Component=unwrap(hit.Component)
    if not valid(hit.Component) then hit.Component=resolveImpactComponent(lib,pc,pawn,hit.ImpactPoint) end
    if hit.bBlockingHit==false or hit.bBlockingHit==0 or not valid(hit.Component) then
        error("Unsupported blocking hit: component="..tostring(hit.Component)..", flag="..tostring(hit.bBlockingHit))
    end
    return hit
end
local function fractureGlass(component,point,direction,impulse)
    if not valid(component) then return false end
    local name=component:GetFullName():lower()
    pcall(function()
        local owner=unwrap(component:GetOwner())
        if valid(owner) then name=name.." "..owner:GetFullName():lower() end
    end)
    if not name:find("glass",1,true) and not name:find("window",1,true) then return false end
    local class,destructible,signature=component:GetClass(),false,false
    for depth=1,16 do
        if not valid(class) then break end
        local name=class:GetFullName()
        if name=="Class /Script/Engine.DestructibleComponent" or name=="Class /Script/ApexDestruction.DestructibleComponent" then
            destructible=true
            class:ForEachFunction(function(fn)
                if fn:GetFName():ToString()~="ApplyDamage" then return end
                local args={}
                fn:ForEachProperty(function(prop)
                    args[#args+1]=prop:GetFName():ToString()..":"..prop:GetClass():GetFName():ToString()
                end)
                signature=table.concat(args,",")=="DamageAmount:FloatProperty,HitLocation:StructProperty,ImpulseDir:StructProperty,ImpulseStrength:FloatProperty"
            end)
            break
        end
        class=class:GetSuperStruct()
    end
    if not destructible or not signature then return false end
    component:ApplyDamage(100,point,direction,impulse)
    return true
end
local function glassShot(pc,pawn,origin,direction,weapon)
    local impact=nil
    local ok,result=pcall(function()
        local finish={X=origin.X+direction.X*8400,Y=origin.Y+direction.Y*8400,Z=origin.Z+direction.Z*8400}
        write("sa_host.shot_stage","trace")
        local hit=traceImpact(pc,pawn,origin,finish)
        if not hit then return false end
        local component=unwrap(hit.Component)
        local point=hit.ImpactPoint
        if not point then return false end
        local distance=0
        for _,axis in ipairs({"X","Y","Z"}) do
            local value=point[axis]
            if type(value)~="number" or value~=value or math.abs(value)>1e8 then return false end
            distance=distance+(value-origin[axis])^2
        end
        if distance>8401^2 then return false end
        impact=hit
        local impulse=impactProfile(weapon)
        write("sa_host.shot_stage","fracture check")
        if fractureGlass(component,point,direction,impulse) or nativeWindowFracture(pc,component,point,direction,impulse) then write("sa_host.shot_stage","fracture complete") return true end
        if nativeNeighborShot(component,pawn) then return true end
        local body=simulatedBody(component)
        if body then
            impulse=physicalImpulse(body,weapon)
            write("sa_host.shot_stage","physics impulse")
            body:AddImpulseAtLocation({X=direction.X*impulse,Y=direction.Y*impulse,Z=direction.Z*impulse},point,FName("None"))
            return true
        end
        return false
    end)
    write("sa_host.glass_error",ok and "0" or tostring(result))
    return ok and result==true,impact
end
local function neighborImpact(hit)
    if not hit then return false end
    local ok,result=pcall(function()
        local actor=unwrap(hit.Component:GetOwner())
        if not valid(actor) then return false end
        local class=actor:GetClass()
        for depth=1,16 do
            if not valid(class) then return false end
            if class:GetFullName()=="Class /Script/HelloNeighbor.Neighbor" then return true end
            class=class:GetSuperStruct()
        end
        return false
    end)
    return ok and result==true
end
local function blastShot(pc,pawn,origin)
    local ok,result=pcall(function()
        local lib=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        local ignored=ownActors(pawn)
        local out={}
        lib:SphereOverlapComponents(pc,origin,650,{0,1,2,3,4,5,6,7},nil,ignored,out)
        local seen,bodies,count,failed={},{},0,0
        local considered,blocked,outside,scanned=0,0,0,0
        for index,entry in ipairs(out) do
            if index>1024 then break end
            scanned=index
            local targetOk,targetError=pcall(function()
                local component=unwrap(entry)
                if not valid(component) then return end
                local address=component:GetAddress()
                if seen[address] then return end
                seen[address]=true
                local owner=unwrap(component:GetOwner())
                if valid(owner) then for _,actor in ipairs(ignored) do if actor:GetAddress()==owner:GetAddress() then return end end end
                local bodyOk,body=pcall(simulatedBody,component)
                if not bodyOk then body=nil end
                local name=component:GetFullName():lower()
                if not body and not name:find("glass",1,true) and not name:find("window",1,true) and
                   not nativeClass(owner,"/Script/HelloNeighbor.Window") and not nativeClass(owner,"/Script/HelloNeighbor.Sosed") then return end
                if considered>=64 then return end
                considered=considered+1
                local point=component:K2_GetComponentLocation()
                local dx,dy,dz=point.X-origin.X,point.Y-origin.Y,point.Z-origin.Z
                local distance=math.sqrt(dx*dx+dy*dy+dz*dz)
                if distance~=distance or distance>=650 then outside=outside+1 return end
                local hit=traceImpact(pc,pawn,origin,point)
                    if hit then
                        local blocker=unwrap(hit.Component)
                        if blocker:GetAddress()~=address and
                           (not body or blocker:GetAddress()~=body:GetAddress()) then
                            blocked=blocked+1 return
                        end
                    end
                local length=math.max(distance,1)
                local direction={X=dx/length,Y=dy/length,Z=dz/length}
                if distance<1 then direction={X=0,Y=0,Z=1} end
                local impulse=6000*(1-distance/650)
                if nativeNeighborShot(component,pawn) or fractureGlass(component,point,direction,impulse) or nativeWindowFracture(pc,component,point,direction,impulse) then count=count+1
                else
                    if body and not bodies[body:GetAddress()] then
                        bodies[body:GetAddress()]=true
                        impulse=physicalImpulse(body,nil,true)*(1-distance/650)
                        body:AddImpulseAtLocation({X=direction.X*impulse,Y=direction.Y*impulse,Z=(direction.Z+.25)*impulse},point,FName("None"))
                        count=count+1
                    end
                end
            end)
            if not targetOk then failed=failed+1 write("sa_host.blast_error",tostring(targetError)) end
        end
        if failed==0 then write("sa_host.blast_error","0") end
        write("sa_host.blast_debug",string.format("origin=%.3f %.3f %.3f overlaps=%d scanned=%d eligible=%d blocked=%d outside=%d applied=%d errors=%d",
            origin.X,origin.Y,origin.Z,#out,scanned,considered,blocked,outside,count,failed))
        return count
    end)
    write("sa_host.blast",tostring(result))
    return ok
end
local function projectileShot(pc,pawn,origin,direction,weapon,generation)
    local finish={X=origin.X+direction.X*8400,Y=origin.Y+direction.Y*8400,Z=origin.Z+direction.Z*8400}
    local hit=traceImpact(pc,pawn,origin,finish)
    if not hit then return true end
    local point=hit.ImpactPoint
    -- Keep the native blast just outside the blocking surface, not inside a wall.
    write("sa_projectile.hit",string.format("%d %d %d %d %d %.5f %.5f %.5f\n",shotPid,movementEpoch,weapon-768,generation,os.time(),
        point.X-direction.X*8,point.Y-direction.Y*8,point.Z-direction.Z*8))
    write("sa_host.projectile",string.format("slot=%d generation=%d native impact pending",weapon-768,generation))
    return true
end
local function throwShot(pc,pawn,origin,direction,weapon,generation)
    if weapon and weapon>=768 and weapon<800 then return projectileShot(pc,pawn,origin,direction,weapon,generation) end
    if weapon and weapon>=256 and weapon<269 then return blastShot(pc,pawn,origin) end
    local handled,hit=glassShot(pc,pawn,origin,direction,weapon)
    if handled then
        write("sa_host.glass_error","0")
        write("sa_host.shot_stage","direct impact complete")
        return true
    end
    if not nativeImpactProxiesEnabled then
        write("sa_host.shot_stage","unsafe native proxy blocked")
        write("sa_host.shot_error","Native throwable fallback disabled after live crash; neighbor reaction unavailable")
        return false
    end
    local gs=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    local now=os.time()
    pcall(function() now=gs:GetRealTimeSeconds(pc) end)
    for i=#shotExpiries,1,-1 do if shotExpiries[i]<=now then table.remove(shotExpiries,i) end end
    if #shotExpiries>=8 then return false end
    if not valid(shotClass) then
        shotClass=nil
        local simple=StaticFindObject("/Script/HelloNeighbor.Simple")
        if not valid(simple) then return false end
        local class,signature=simple,false
        for depth=1,6 do
            if not valid(class) then break end
            class:ForEachFunction(function(fn)
                if fn:GetFName():ToString()=="OnThrow" then
                    local args={}
                    fn:ForEachProperty(function(prop) args[#args+1]=prop:GetClass():GetFName():ToString() end)
                    if #args==1 and args[1]=="ObjectProperty" then signature=true end
                end
            end)
            class=class:GetSuperStruct()
        end
        if not signature then write("sa_host.shot_error","OnThrow signature unavailable") return false end
        local items={}
        gs:GetAllActorsOfClass(pawn,simple,items)
        local score=-1
        for _,entry in ipairs(items) do
            local item=unwrap(entry)
            if valid(item) then
                local name=item:GetFullName():lower()
                local rank=(name:find("ball",1,true) or name:find("apple",1,true)) and 3 or
                    (name:find("can",1,true) or name:find("book",1,true)) and 2 or 1
                if rank>score then score=rank shotClass=item:GetClass() end
            end
        end
    end
    if not valid(shotClass) then return false end
    local neighbor=neighborImpact(hit)
    -- Spawn just before a verified first-blocking neighbor contact. The native
    -- throwable still has to collide; no AI state or arbitrary damage is forced.
    local from=neighbor and {X=hit.ImpactPoint.X-direction.X*40,Y=hit.ImpactPoint.Y-direction.Y*40,Z=hit.ImpactPoint.Z-direction.Z*40} or
        {X=origin.X+direction.X*12,Y=origin.Y+direction.Y*12,Z=origin.Z+direction.Z*12}
    local scale=neighbor and 1 or .12
    local transform={Rotation={X=0,Y=0,Z=0,W=1},Translation=from,Scale3D={X=scale,Y=scale,Z=scale}}
    local actor=gs:BeginDeferredActorSpawnFromClass(pc,shotClass,transform,1,nil)
    if not valid(actor) then return false end
    shotExpiries[#shotExpiries+1]=now+.45
    local ok,err=pcall(function()
        gs:FinishSpawningActor(actor,transform)
        actor:SetActorHiddenInGame(true)
        actor:SetLifeSpan(.45)
        actor:SetActorScale3D(transform.Scale3D)
        actor:OnThrow(pawn)
        actor:SetActorHiddenInGame(true)
        actor:SetLifeSpan(.45)
        local root=actor:K2_GetRootComponent()
        if not valid(root) then error("Shot proxy root unavailable") end
        root:SetSimulatePhysics(true)
        root:SetNotifyRigidBodyCollision(true)
        pcall(function() root:IgnoreActorWhenMoving(pawn,true) end)
        local mass=neighbor and (weapon and weapon>=25 and weapon<=27 and 1 or .25) or impactProfile(weapon)/6000
        root:SetMassOverrideInKg(FName("None"),mass,true)
        pcall(function() root:SetUseCCD(true,FName("None")) end)
        root:SetPhysicsLinearVelocity({X=direction.X*6000,Y=direction.Y*6000,Z=direction.Z*6000},false,FName("None"))
    end)
    if not ok then
        pcall(function() actor:K2_DestroyActor() end)
        write("sa_host.shot_error",tostring(err))
        return false
    end
    write("sa_host.shot_error","0")
    if neighbor then write("sa_host.neighbor_hit","native throwable dispatched; reaction unverified") end
    return true
end
local function shotTick(pc,pawn,active)
    local file=io.open("sa_shots.txt","r") if not file then return end
    local text=file:read("*a") file:close()
    local header,rows=text:match("^([^\n]+)\n(.*)$") if not header then return end
    local pid,latest,epoch,stamp=header:match("^(%d+) (%d+) (%d+) (%d+)$")
    pid,latest,epoch,stamp=tonumber(pid),tonumber(latest),tonumber(epoch),tonumber(stamp)
    if not stamp or not pid or not latest then return end
    if shotPid~=pid then shotPid,shotSerial=pid,(latest-16)%4294967296 end
    if not active or epoch~=movementEpoch or math.abs(os.time()-stamp)>1 then shotSerial=latest return end
    local pending=(latest-shotSerial)%4294967296
    if pending>16 and pending<2147483648 then shotSerial=(latest-16)%4294967296 end
    local processed,deferred=0,false
    for row in rows:gmatch("[^\n]+") do
        local v={}
        for token in row:gmatch("%S+") do
            local value=tonumber(token)
            if not value or value~=value or math.abs(value)>1e8 then v={} break end
            v[#v+1]=value
        end
        if #v==8 and v[1]%1==0 and v[2]%1==0 and ((v[1]-shotSerial)%4294967296)>0 and ((v[1]-shotSerial)%4294967296)<=16 then
            if processed>=4 then deferred=true break end
            local length=v[6]*v[6]+v[7]*v[7]+v[8]*v[8]
            if length>.98 and length<1.02 and ((v[2]>=22 and v[2]<=34) or v[2]==38 or (v[2]>=256 and v[2]<269) or (v[2]>=768 and v[2]<800)) then
                processed=processed+1
                local ok,result=pcall(throwShot,pc,pawn,{X=v[3],Y=v[4],Z=v[5]},{X=v[6],Y=v[7],Z=v[8]},v[2],v[1])
                if ok and result then write("sa_host.shot",string.format("%d %d",pid,v[1]))
                elseif not ok then write("sa_host.shot_error",tostring(result)) end
            end
            shotSerial=v[1]
        end
    end
    if not deferred then shotSerial=latest end
end
local function hideAttachments(pawn)
    for i,actor in ipairs(ownActors(pawn)) do
        if i>1 then pcall(function()
            local address=actor:GetAddress()
            if not attachedHidden[address] then
                attachedHidden[address]={actor=actor,hidden=actor.bHidden==true,collision=actor:GetActorEnableCollision()}
                print("[SANeighbor] hide carried host actor: "..actor:GetFullName().."\n")
            end
            actor:SetActorHiddenInGame(true)
            actor:SetActorEnableCollision(false)
        end) end
    end
end
local function propertyOffset(path, name)
    local object, offset = StaticFindObject(path), nil
    if not valid(object) then return nil end
    object:ForEachProperty(function(p)
        if p:GetFName():ToString() == name then offset = p:GetOffset_Internal() end
    end)
    return offset
end
local function publishCamera(pc)
    if not offsets then
        local cache = propertyOffset("/Script/Engine.PlayerCameraManager", "CameraCachePrivate") or
                      propertyOffset("/Script/Engine.PlayerCameraManager", "CameraCache")
        local pov = propertyOffset("/Script/Engine.CameraCacheEntry", "POV")
        local loc = propertyOffset("/Script/Engine.MinimalViewInfo", "Location")
        local rot = propertyOffset("/Script/Engine.MinimalViewInfo", "Rotation")
        local fov = propertyOffset("/Script/Engine.MinimalViewInfo", "FOV")
        if not (cache and pov and loc and rot and fov) then error("Camera reflection incomplete") end
        offsets = {cache + pov + loc, cache + pov + rot, cache + pov + fov}
    end
    local address = pc.PlayerCameraManager:GetAddress()
    if published ~= address then
        write("hn_camera.txt", string.format("%d %d %d %d 0\n", address, offsets[1], offsets[2], offsets[3]))
        published = address
    end
end
local function controller()
    local ok, pc = pcall(function()
        return StaticFindObject("/Engine/Transient.GameEngine_0").GameInstance.LocalPlayers[1].PlayerController
    end)
    if ok and valid(pc) and valid(pc.Pawn) then return pc end
    for _, candidate in ipairs(FindAllOf("PlayerController") or {}) do
        local good, use = pcall(function()
            return valid(candidate.Pawn) and not candidate.Pawn:GetFullName():find("/Game/Maps/Start.Start", 1, true)
        end)
        if good and use then return candidate end
    end
end
local function restoreView(falling,keepMovement)
    if not keepMovement then lastControlledHost=nil restoreBarriers() restoreWindowShotCollision() end
    if hiddenCursor then
        pcall(function()
            if valid(hiddenCursor.widget) and hiddenCursor.widget:GetVisibility()==2 then
                hiddenCursor.widget:SetVisibility(hiddenCursor.visibility)
            end
        end)
        hiddenCursor=nil
    end
    if lookOwned then
        if valid(currentPc) then pcall(function() currentPc:SetIgnoreLookInput(false) end) end
        lookOwned=false
    end
    if not keepMovement then
        for _,entry in pairs(attachedHidden) do
            if valid(entry.actor) then pcall(function()
                entry.actor:SetActorHiddenInGame(entry.hidden)
                entry.actor:SetActorEnableCollision(entry.collision)
            end) end
        end
        attachedHidden={}
    end
    if moveOwned and not keepMovement then
        if valid(currentPc) then pcall(function() currentPc:SetIgnoreMoveInput(false) end) end
        if valid(currentPawn) then pcall(function()
            if savedCapsule then currentPawn.CapsuleComponent:SetCapsuleSize(savedCapsule[1],savedCapsule[2],true) end
            local movement=currentPawn.CharacterMovement
            -- Swept native moves do not update CharacterMovement's cached floor.
            -- Falling forces a new floor query instead of trusting an old walking floor.
            movement:SetMovementMode(falling and 3 or (savedMovementMode==0 and 3 or savedMovementMode),0)
            if falling then
                if type(movement.GravityScale)=="number" and movement.GravityScale<=0 then movement.GravityScale=1 end
                movement:SetComponentTickEnabled(true)
                movement:StopMovementImmediately()
            end
        end) end
        moveOwned=false
        savedCapsule=nil capsuleVehicle=false
    end
    if ownsView then
        if valid(currentPc) and valid(currentPawn) then
            pcall(function()
                local view=currentPc:GetViewTarget()
                if valid(view) and valid(cameraActor) and view:GetAddress()==cameraActor:GetAddress() then
                    currentPc:SetViewTargetWithBlend(valid(originalView) and originalView or currentPawn, 0, 0, 0, false)
                end
            end)
            pcall(function() currentPawn:SetActorHiddenInGame(false) end)
        end
        ownsView, originalView = false, nil
    end
    write("sa_view.txt","0\n")
end
local function playerState(active, position, half, velocity)
    if not cjMode then moveOrigin=nil nativeSequence=nil write("sa_player.txt", "0\n") return end
    if position then lastPose = {position.X, position.Y, position.Z - half} end
    if not moveOrigin and position and active then moveOrigin={X=position.X,Y=position.Y,Z=position.Z} end
    local feedback=active and correction or {X=0,Y=0,Z=0}
    local serial=sentCorrection
    write("sa_player.txt", string.format("2 %d %d %.5f %.5f %.5f %.5f %.5f %.5f %d %d\n",
        active and 1 or 0, serial, lastPose[1], lastPose[2], lastPose[3], feedback.X, feedback.Y, feedback.Z,ticks,movementEpoch))
end
local function inactive(reason)
    deathArmed=false awaitingRespawn=false
    if nativeFadeOwned and valid(currentPc) then pcall(function() currentPc.PlayerCameraManager:SetManualCameraFade(0,{R=0,G=0,B=0,A=1},false) end) end
    nativeFadeOwned=false
    if reason=="controller unavailable" or reason=="main menu" or reason=="layer disabled" then write("sa_host.clock","0\n") end
    write("sa_host.menu","0\n")
    restoreView(true)
    groundContact=nil
    groundSample=nil groundTick=-100
    playerState(false)
    write("sa_host.txt", "0\n")
    write("sa_host.reason",reason or "inactive")
end
local function solidAt(pawn,point,ignored)
    local out={}
    local ksl=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    -- These yes/no overlap queries avoid Lua marshalling of FHitResult.
    ksl:BoxOverlapComponents(pawn,point,{X=3,Y=3,Z=8},{0,1,3,7},nil,ignored or {pawn},out)
    for _,component in ipairs(out) do
        component=unwrap(component)
        if valid(component) and component:GetCollisionResponseToChannel(2)==2 then
            local own=false
            local owner=unwrap(component:GetOwner())
            if valid(owner) then
                for _,actor in ipairs(ignored or {pawn}) do if owner:GetAddress()==actor:GetAddress() then own=true break end end
            end
            if not own then
                local name=component:GetFullName()
                if not loggedSupport[name] then
                    loggedSupport[name]=true
                    print("[SANeighbor] support component: "..name.."\n")
                end
                return true
            end
        end
    end
    return false
end
local function sampleGround(pawn,position,half)
    local feet=position.Z-half
    local ignored=ownActors(pawn)
    local probe={X=position.X,Y=position.Y,Z=feet+20}
    local accelerated,height=pcall(function()
        local ksl=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        local hit={}
        local color={R=0,G=0,B=0,A=0}
        local blocked=ksl:BoxTraceSingleForObjects(pawn,probe,{X=position.X,Y=position.Y,Z=feet-700},
            {X=3,Y=3,Z=8},{Pitch=0,Yaw=0,Roll=0},{0,1,3,7},false,ignored,0,hit,true,color,color,0)
        if blocked==false then return false end
        if blocked~=true or not hit.ImpactPoint then error("Unsupported ground sweep") end
        local top=hit.ImpactPoint.Z
        if type(top)~="number" or top~=top or top>feet+4 or top<feet-708 then error("Invalid ground sweep point") end
        if solidAt(pawn,{X=position.X,Y=position.Y,Z=top-4},ignored) and
           not solidAt(pawn,{X=position.X,Y=position.Y,Z=top+16},ignored) then return top end
        error("Ground sweep needs overlap fallback")
    end)
    if accelerated then return height~=false and height or nil end
    if solidAt(pawn,probe,ignored) then return nil end
    local above=probe.Z
    for depth=16,720,16 do
        probe.Z=feet+20-depth
        if solidAt(pawn,probe,ignored) then
            local below=probe.Z
            -- Locate the top of the overlap interval; subtract the query's half-height.
            for i=1,6 do
                probe.Z=(above+below)*.5
                if solidAt(pawn,probe,ignored) then below=probe.Z else above=probe.Z end
            end
            local top=(above+below)*.5-8
            if top<=feet+4 then return top end
            return nil
        end
        above=probe.Z
    end
    return nil
end
local function publishGround(pawn,position,half)
    -- Empty-air searches can traverse45 probes; swept landings still force an immediate refresh.
    local moved=not groundProbePosition or
        (position.X-groundProbePosition.X)^2+(position.Y-groundProbePosition.Y)^2>12^2 or
        math.abs(position.Z-groundProbePosition.Z)>8 or half~=groundProbePosition.half
    if moved or ticks-groundTick>=(groundSample and 2 or 8) then
        local contact=groundContact
        local supported=false
        if contact and contact.epoch==movementEpoch and math.abs(contact.X-position.X)<1 and math.abs(contact.Y-position.Y)<1 and math.abs(contact.Z-(position.Z-half))<4 then
            local ignored=ownActors(pawn)
            local ksl=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            local radius=pawn.CapsuleComponent:GetScaledCapsuleRadius()
            local function overlaps(z)
                local out,set={},{}
                ksl:CapsuleOverlapComponents(pawn,{X=position.X,Y=position.Y,Z=z},radius,half,{0,1,3,7},nil,ignored,out)
                for _,entry in ipairs(out) do
                    local component=unwrap(entry)
                    if valid(component) and component:GetCollisionResponseToChannel(2)==2 then
                        local owner=unwrap(component:GetOwner())
                        local own=false
                        if valid(owner) then for _,actor in ipairs(ignored) do if owner:GetAddress()==actor:GetAddress() then own=true break end end end
                        if not own then set[component:GetAddress()]=true end
                    end
                end
                return set
            end
            -- A support disappears when raised, unlike a wall beside the capsule.
            local lower,upper=overlaps(position.Z-2),overlaps(position.Z+2)
            for address in pairs(lower) do if not upper[address] then supported=true break end end
            -- A tilted wall can leave the large capsule when raised, too. It is not
            -- floor unless a small probe confirms a clear top directly under the feet.
            if supported then
                local feet=position.Z-half
                supported=solidAt(pawn,{X=position.X,Y=position.Y,Z=feet-8},ignored)
                    and not solidAt(pawn,{X=position.X,Y=position.Y,Z=feet+16},ignored)
            end
        end
        if supported then groundSample=position.Z-half
        else groundContact=nil groundSample=sampleGround(pawn,position,half) end
        groundTick=ticks
        groundProbePosition={X=position.X,Y=position.Y,Z=position.Z,half=half}
    end
    if not capsuleVehicle or not groundSample then
        groundSlopeX,groundSlopeY=0,0 groundPlaneTick=-100
    elseif ticks-groundPlaneTick>=8 then
        groundPlaneTick=ticks
        local function height(dx,dy)
            return sampleGround(pawn,{X=position.X+dx,Y=position.Y+dy,Z=position.Z+96},half)
        end
        local xp,xm,yp,ym=height(84,0),height(-84,0),height(0,84),height(0,-84)
        groundSlopeX,groundSlopeY=0,0
        if xp and xm and yp and ym and math.abs((xp+xm)*.5-groundSample)<6 and math.abs((yp+ym)*.5-groundSample)<6 then
            local sx,sy=(xp-xm)/168,(yp-ym)/168
            if sx*sx+sy*sy<=.64 then groundSlopeX,groundSlopeY=sx,sy end
        end
    end
    write("sa_ground.txt",string.format("%d %.5f %d %d %.6f %.6f %.3f %.3f\n",groundSample and 1 or 0,groundSample or 0,ticks,movementEpoch,groundSlopeX,groundSlopeY,position.X,position.Y))
end
local function labRequest(pawn)
    local enabledFile=io.open("sa_lab.enabled","r")
    if not enabledFile then return false end
    local on=enabledFile:read("*a") enabledFile:close()
    local expires=tonumber(on:match("^1%s+(%d+)"))
    if not expires or expires<os.time() or expires>os.time()+30 then return false end
    local request=io.open("sa_lab.request","r")
    if not request then return true end
    local text=request:read("*a") request:close()
    local serial,command,value=text:match("^(%d+)%s+(%a+)%s*(%d*)")
    if not serial or serial==labSerial then return true end
    labSerial=serial
    if command=="hit" or command=="native" or command=="inspect" then
        local pc=controller()
        local kind=tonumber(value) or 1
        local class=kind==1 and "Window" or kind==2 and "Simple" or "Sosed"
        local origin=pawn:K2_GetActorLocation()
        origin={X=origin.X,Y=origin.Y,Z=origin.Z+20}
        local candidates={}
        local probeInfo={}
        local actors=actorsOfClass(pawn,"/Script/HelloNeighbor."..class)
        probeInfo[#probeInfo+1]="world actors="..#actors
        for _,entry in ipairs(actors) do
            local actor=unwrap(entry)
            probeInfo[#probeInfo+1]="entry="..tostring(actor).." valid="..tostring(valid(actor))
            if valid(actor) and not actor:GetFullName():find("Default__",1,true) then
              local good,why=pcall(function()
                probeInfo[#probeInfo+1]=actor:GetFullName()
                local component=kind==1 and unwrap(actor.GlassMesh1) or unwrap(actor:K2_GetRootComponent())
                if not valid(component) then probeInfo[#probeInfo+1]="missing root/pane" return end
                if kind==1 and actor.bCrashed1 then return end
                local point=component:K2_GetComponentLocation()
                local d=(point.X-origin.X)^2+(point.Y-origin.Y)^2+(point.Z-origin.Z)^2
                probeInfo[#probeInfo+1]=actor:GetFullName().." distance="..math.sqrt(d)
                if d>100 and d<(kind==3 and 20000^2 or 3000^2) then candidates[#candidates+1]={actor=actor,component=component,point=point,d=d} end
              end)
              if not good then probeInfo[#probeInfo+1]=tostring(why) end
            end
        end
        table.sort(candidates,function(a,b) return a.d<b.d end)
        local lines={"probe "..class.." candidates="..#candidates}
        for index=1,math.min(8,#probeInfo) do lines[#lines+1]=probeInfo[index] end
        for index,target in ipairs(candidates) do
            if index>12 then break end
            if command=="inspect" then
                lines[#lines+1]=target.actor:GetFullName()
                for pane=1,3 do pcall(function()
                    local mesh=unwrap(target.actor["GlassMesh"..pane])
                    if not valid(mesh) then return end
                    local p=mesh:K2_GetComponentLocation()
                    lines[#lines+1]=string.format("pane%d pos=%.3f %.3f %.3f broken=%s visible=%s collision=%s visibility=%s",pane,p.X,p.Y,p.Z,
                        tostring(target.actor["bCrashed"..pane]),tostring(mesh:IsVisible()),tostring(mesh:GetCollisionEnabled()),tostring(mesh:GetCollisionResponseToChannel(3)))
                end) end
                if index==1 then
                    local cls=target.component:GetClass()
                    for depth=1,12 do
                        if not valid(cls) then break end
                        cls:ForEachFunction(function(fn)
                            if not fn:GetFName():ToString():find("TraceComponent",1,true) then return end
                            local args={}
                            fn:ForEachProperty(function(prop) args[#args+1]=prop:GetFName():ToString()..":"..prop:GetClass():GetFName():ToString() end)
                            lines[#lines+1]=fn:GetFName():ToString().."("..table.concat(args,",")..")"
                        end)
                        cls=cls:GetSuperStruct()
                    end
                end
            else
            local length=math.sqrt(target.d)
            local direction={X=(target.point.X-origin.X)/length,Y=(target.point.Y-origin.Y)/length,Z=(target.point.Z-origin.Z)/length}
            local handled,hit
            if command=="native" then
                if kind==1 then handled=nativeWindowFracture(pc,target.component,target.point,direction,90)
                elseif kind==3 then handled=nativeNeighborShot(target.component,pawn)
                else
                    local body=simulatedBody(target.component)
                    if body then body:AddImpulseAtLocation({X=direction.X*physicalImpulse(body,22),Y=direction.Y*physicalImpulse(body,22),Z=120},target.point,FName("None")) handled=true end
                end
            else handled,hit=glassShot(pc,pawn,origin,direction,22) end
            lines[#lines+1]=target.actor:GetFullName().." handled="..tostring(handled).." hit="..(hit and hit.Component:GetFullName() or "none")
            if handled then break end
            end
        end
        write("sa_lab.impact",table.concat(lines,"\n"))
    elseif command=="reset" then
        StaticFindObject("/Script/Engine.Default__GameplayStatics"):SetGamePaused(pawn,false)
        if cjMode then toggleCJ() end
        print("[SANeighbor] lab gravity before reset: "..tostring(pawn.CharacterMovement.GravityScale).."\n")
        pawn.CharacterMovement.GravityScale=1
        pawn.CharacterMovement:SetComponentTickEnabled(true)
        pawn:SetActorTickEnabled(true)
        pawn:SetActorEnableCollision(true)
        pawn.CharacterMovement:SetMovementMode(3,0)
        pawn.CharacterMovement:StopMovementImmediately()
        local p=pawn:K2_GetActorLocation()
        local half=pawn.CapsuleComponent:GetScaledCapsuleHalfHeight()
        local floor=sampleGround(pawn,p,half)
        if floor then pawn:K2_SetActorLocation({X=p.X,Y=p.Y,Z=floor+half+4},true,{},false) end
        print("[SANeighbor] lab reset: unpaused once, host gravity restored\n")
    elseif command=="start" and not cjMode then toggleCJ()
    elseif command=="toggle" then toggleCJ()
    elseif command=="air" and cjMode and moveOwned then
        local p=pawn:K2_GetActorLocation()
        p={X=p.X,Y=p.Y,Z=p.Z+math.max(100,math.min(900,tonumber(value) or 600))}
        pawn:K2_SetActorLocation(p,false,{},false)
        movementEpoch=movementEpoch+1 moveOrigin=nil nativeSequence=nil sentCorrection=0
        correction={X=0,Y=0,Z=0} groundSample=nil groundTick=-100
        print("[SANeighbor] lab air displacement; native gravity must return to host support\n")
    end
    local p=pawn:K2_GetActorLocation()
    write("sa_lab.reply",string.format("%s %s %d %d %.3f %.3f %.3f\n",serial,command,cjMode and 1 or 0,moveOwned and 1 or 0,p.X,p.Y,p.Z))
    return true
end
local function guestReady()
    for attempt=1,3 do
        local f=io.open("sa_player.ready","r")
        if f then
            local text=f:read("*a") f:close()
            local values={}
            for value in text:gmatch("[^%s]+") do
                local number=tonumber(value)
                if not number or number~=number or math.abs(number)>1e12 then lastGuestReply=nil return nil end
                values[#values+1]=number
            end
            if values[1]==0 then lastGuestReply=nil return nil end
            if #values==16 or #values==17 or #values==18 or #values==19 then
                if values[1]~=1 or math.abs(os.time()-values[2])>2 then lastGuestReply=nil return nil end
                lastGuestReply,lastGuestTick=values,ticks
                return values
            end
        end
    end
    if lastGuestReply and ticks-lastGuestTick<=10 and math.abs(os.time()-lastGuestReply[2])<=2 then return lastGuestReply end
    lastGuestReply=nil
    return nil
end
local function vehiclePath(pawn,old,desired,half)
    local dx,dy,dz=desired.X-old.X,desired.Y-old.Y,desired.Z-old.Z
    local length=math.sqrt(dx*dx+dy*dy+dz*dz)
    if length<.01 then return desired end
    local horizontal=math.sqrt(dx*dx+dy*dy)
    local fx,fy=0,0
    if horizontal>.01 then fx,fy=dx/horizontal,dy/horizontal end
    local ksl=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local ignored=ownActors(pawn)
    -- This box encloses all three chassis capsules over the complete movement.
    -- Only a supported, explicitly empty result may bypass the detailed sweep.
    local broad={}
    local broadOk,overlap=pcall(function()
        return ksl:BoxOverlapComponents(pawn,
            {X=(old.X+desired.X)*.5,Y=(old.Y+desired.Y)*.5,Z=(old.Z+desired.Z)*.5+4},
            {X=math.abs(dx)*.5+100+math.abs(fx)*90,Y=math.abs(dy)*.5+100+math.abs(fy)*90,Z=math.abs(dz)*.5+math.max(100,half-4)},
            {0,1,3,7},nil,ignored,broad)
    end)
    if broadOk and overlap==false and #broad==0 then return desired end
    local function blocked(t)
        -- Three overlapping volumes cover the chassis, not just the driver's centre.
        for _,offset in ipairs({-90,0,90}) do
            local out={}
            ksl:CapsuleOverlapComponents(pawn,{X=old.X+dx*t+fx*offset,Y=old.Y+dy*t+fy*offset,Z=old.Z+dz*t+4},100,math.max(100,half-4),{0,1,3,7},nil,ignored,out)
            for _,entry in ipairs(out) do
                local component=unwrap(entry)
                if valid(component) and component:GetCollisionResponseToChannel(2)==2 then
                    local owner=unwrap(component:GetOwner())
                    local own=false
                    if valid(owner) then
                        for _,actor in ipairs(ignored) do if owner:GetAddress()==actor:GetAddress() then own=true break end end
                    end
                    if not own then return true end
                end
            end
        end
        return false
    end
    -- A bounded spatial sweep catches thin props even between two bridge updates.
    local steps=math.min(32,math.max(1,math.ceil(length/16)))
    local safe=0
    for i=1,steps do
        local t=i/steps
        if blocked(t) then
            local low,high=safe,t
            for j=1,5 do
                local mid=(low+high)*.5
                if blocked(mid) then high=mid else low=mid end
            end
            return {X=old.X+dx*low,Y=old.Y+dy*low,Z=old.Z+dz*low}
        end
        safe=t
    end
    return desired
end
local function nativeMovement(pc,pawn,half,reply)
    if reply[8]~=2 or not moveOrigin then return pawn:K2_GetActorLocation() end
    if not moveOwned then
        savedMovementMode=pawn.CharacterMovement.MovementMode
        pc:SetIgnoreMoveInput(true)
        pawn.CharacterMovement:DisableMovement()
        pcall(function() savedCapsule={pawn.CapsuleComponent:GetUnscaledCapsuleRadius(),pawn.CapsuleComponent:GetUnscaledCapsuleHalfHeight()} end)
        moveOwned=true
    end
    -- Story events can restore walking without replacing the pawn. Keep one
    -- movement owner, including ticks that reuse the last guest sequence.
    if pawn.CharacterMovement.MovementMode~=0 then pawn.CharacterMovement:DisableMovement() end
    if reply[19] and reply[19]~=movementEpoch then return pawn:K2_GetActorLocation() end
    if savedCapsule and capsuleVehicle~=(reply[9]==1) then
        capsuleVehicle=reply[9]==1
        local oldHalf=pawn.CapsuleComponent:GetScaledCapsuleHalfHeight()
        local scale=oldHalf/pawn.CapsuleComponent:GetUnscaledCapsuleHalfHeight()
        if scale<=0 then scale=1 end
        pawn.CapsuleComponent:SetCapsuleSize(capsuleVehicle and 105/scale or savedCapsule[1],capsuleVehicle and math.max(105/scale,savedCapsule[2]) or savedCapsule[2],true)
        local shift=pawn.CapsuleComponent:GetScaledCapsuleHalfHeight()-oldHalf
        local p=pawn:K2_GetActorLocation()
        pawn:K2_SetActorLocation({X=p.X,Y=p.Y,Z=p.Z+shift},false,{},false)
        moveOrigin.Z=moveOrigin.Z+shift
        if lastControlledHost then lastControlledHost.Z=lastControlledHost.Z+shift end
    end
    if reply[3]==nativeSequence or reply[7]~=sentCorrection then return pawn:K2_GetActorLocation() end
    nativeSequence=reply[3]
    local desired={X=moveOrigin.X+(reply[4]-reply[14])*84,Y=moveOrigin.Y-(reply[5]-reply[15])*84,Z=moveOrigin.Z+(reply[6]-reply[16])*84}
    local old=pawn:K2_GetActorLocation()
    local dx,dy,dz=desired.X-old.X,desired.Y-old.Y,desired.Z-old.Z
    local hx=lastControlledHost and old.X-lastControlledHost.X or 0
    local hy=lastControlledHost and old.Y-lastControlledHost.Y or 0
    local hz=lastControlledHost and old.Z-lastControlledHost.Z or 0
    if hx*hx+hy*hy+hz*hz>420*420 then
        -- Only an external host relocation changes the anchor. A blocked guest
        -- can drift far from its host without either game having teleported.
        movementEpoch=movementEpoch+1 moveOrigin={X=old.X,Y=old.Y,Z=old.Z}
        correction={X=0,Y=0,Z=0} sentCorrection=ticks nativeSequence=nil
        lastControlledHost={X=old.X,Y=old.Y,Z=old.Z}
        write("sa_host.relocation",string.format("epoch=%d external_delta=%.3f %.3f %.3f host=%.3f %.3f %.3f",movementEpoch,hx,hy,hz,old.X,old.Y,old.Z))
        print("[SANeighbor] movement reanchor after script relocation\n")
        return old
    end
    local hit={}
    local target=reply[9]==1 and vehiclePath(pawn,old,desired,half) or desired
    pawn:K2_SetActorLocation(target,true,hit,false)
    local actual=pawn:K2_GetActorLocation()
    if desired.Z<old.Z-.5 and actual.Z>desired.Z+.5 then
        -- Separate downward support from an earlier sideways wall collision.
        if math.abs(actual.X-desired.X)>.5 or math.abs(actual.Y-desired.Y)>.5 then
            pawn:K2_SetActorLocation({X=actual.X,Y=actual.Y,Z=desired.Z},true,{},false)
            actual=pawn:K2_GetActorLocation()
        end
        if actual.Z>desired.Z+.5 and actual.Z<=old.Z+.5 then
            groundContact={X=actual.X,Y=actual.Y,Z=actual.Z-half,epoch=movementEpoch}
            groundTick=-100
        end
    end
    if math.abs(actual.X-desired.X)>.5 and math.abs(actual.Y-desired.Y)>.5 then
        -- Resolve the still-free axis with real sweeps instead of cancelling a diagonal move.
        pawn:K2_SetActorLocation({X=desired.X,Y=actual.Y,Z=actual.Z},true,{},false)
        actual=pawn:K2_GetActorLocation()
        pawn:K2_SetActorLocation({X=actual.X,Y=desired.Y,Z=actual.Z},true,{},false)
        actual=pawn:K2_GetActorLocation()
    end
    local blockedX,blockedY=actual.X-desired.X,actual.Y-desired.Y
    local standing=not reply[18] or math.floor(reply[18]/8)%2==1
    local stepHeight=tonumber(pawn.CharacterMovement.MaxStepHeight) or 45
    stepHeight=math.max(0,math.min(45,stepHeight))
    local rawControls=math.floor((reply[17] or 0)/16384)%2==1
    local jumping=(not rawControls and math.floor((reply[17] or 0))%2==1) or (reply[18] and math.floor(reply[18]/32)%2==1)
    local jetpack=reply[18] and math.floor(reply[18]/4)%2==1
    if jumping and not jumpWasDown and groundSample and old.Z-half-groundSample<=70 and old.Z-half-groundSample>=-4 then
        mantleUntil=ticks+60 mantleBase=groundSample
    end
    jumpWasDown=jumping
    local mantle=mantleBase and ticks<=mantleUntil and not jetpack and old.Z-half<=mantleBase+90
    local climbTarget={X=desired.X,Y=desired.Y,Z=desired.Z}
    if mantle then
        stepHeight=math.max(0,math.min(90,mantleBase+90-(old.Z-half)))
    end
    local length=math.sqrt(dx*dx+dy*dy)
    if length>.1 and blockedX*blockedX+blockedY*blockedY>1 then
        local radius=pawn.CapsuleComponent:GetScaledCapsuleRadius()
        -- Walking steps may rise, but must not add horizontal sprint distance.
        local reach=mantle and math.max(0,math.min(100,radius*2+12)-length) or 0
        climbTarget.X=climbTarget.X+dx/length*reach
        climbTarget.Y=climbTarget.Y+dy/length*reach
    end
    if reply[9]~=1 and (standing or mantle) and blockedX*blockedX+blockedY*blockedY>1 and
       ((mantle and desired.Z>=old.Z-4 and desired.Z<=old.Z+90) or math.abs(desired.Z-old.Z)<4) and stepHeight>0 then
        local blocked={X=actual.X,Y=actual.Y,Z=actual.Z}
        pawn:K2_SetActorLocation({X=old.X,Y=old.Y,Z=old.Z+stepHeight},true,{},false)
        local raised=pawn:K2_GetActorLocation()
        local success=false
        if raised.Z>=old.Z+stepHeight-.5 then
            pawn:K2_SetActorLocation({X=climbTarget.X,Y=climbTarget.Y,Z=raised.Z},true,{},false)
            local forward=pawn:K2_GetActorLocation()
            local floor=sampleGround(pawn,forward,half)
            if math.abs(forward.X-climbTarget.X)<.5 and math.abs(forward.Y-climbTarget.Y)<.5 and floor and floor>=old.Z-half-2 and floor<=old.Z-half+stepHeight+.5 then
                pawn:K2_SetActorLocation({X=forward.X,Y=forward.Y,Z=floor+half+.6},true,{},false)
                local landed=pawn:K2_GetActorLocation()
                success=math.abs(landed.X-forward.X)<.5 and math.abs(landed.Y-forward.Y)<.5 and math.abs(landed.Z-(floor+half+.6))<1
            end
        end
        if not success then pawn:K2_SetActorLocation(blocked,false,{},false) end
        actual=pawn:K2_GetActorLocation()
    end
    correction={X=actual.X-desired.X,Y=actual.Y-desired.Y,Z=actual.Z-desired.Z}
    for axis,value in pairs(correction) do if math.abs(value)<.5 then correction[axis]=0 end end
    -- Free movement needs no round-trip acknowledgement. Wait only for real collisions.
    if correction.X*correction.X+correction.Y*correction.Y+correction.Z*correction.Z>.01 then sentCorrection=ticks end
    lastControlledHost={X=actual.X,Y=actual.Y,Z=actual.Z}
    return actual
end
local function readNativeCamera()
    for attempt=1,3 do
        local file=io.open("sa_native_camera.txt","r")
        if file then
            local text=file:read("*a") file:close()
            local values={}
            for token in text:gmatch("[^%s]+") do
                local value=tonumber(token)
                if not value or value~=value or math.abs(value)>1e12 then nativeCameraReply=nil return nil end
                values[#values+1]=value
            end
            if values[1]==0 then nativeCameraReply=nil return nil end
            if (#values==13 or #values==16) and values[1]==1 and math.abs(os.time()-values[2])<=2 and values[3]>0 and values[4]>0 and values[11]>=10 and values[11]<=160 and values[13]==movementEpoch then
                if values[3]~=nativeCameraFrame or values[4]~=nativeCameraPid then
                    nativeCameraTick=ticks nativeCameraFrame=values[3] nativeCameraPid=values[4]
                end
                if ticks-nativeCameraTick>15 then nativeCameraReply=nil return nil end
                nativeCameraReply=values return values
            end
            if #values>0 then nativeCameraReply=nil return nil end
        end
    end
    if nativeCameraReply and nativeCameraReply[13]==movementEpoch and ticks-nativeCameraTick<=10 and math.abs(os.time()-nativeCameraReply[2])<=2 then return nativeCameraReply end
    nativeCameraReply=nil return nil
end
local cameraRetryTick=0
local function nativeView(pc, pawn, position, half, reply)
    local native=readNativeCamera()
    if not native then return false end
    hideAttachments(pawn)
    if not valid(cameraActor) then
        if ticks<cameraRetryTick then return false end
        local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
        local cls = StaticFindObject("/Script/Engine.CameraActor")
        local xf = {Rotation={X=0,Y=0,Z=0,W=1}, Translation={X=position.X,Y=position.Y,Z=position.Z}, Scale3D={X=1,Y=1,Z=1}}
        cameraActor = gs:BeginDeferredActorSpawnFromClass(pc, cls, xf, 1, nil)
        if not valid(cameraActor) then
            cameraRetryTick=ticks+120
            write("sa_host.camera_error","Camera spawn failed; movement retained; retry pending")
            return false
        end
        gs:FinishSpawningActor(cameraActor, xf)
        cameraRetryTick=0
        write("sa_host.camera_error","0")
    end
    local vehicle=reply[9]==1
    local aim=math.floor((reply[17] or 0)/16)%2==1
    if vehicle then aim=false end
    local pivot={X=position.X,Y=position.Y,Z=position.Z+half*.1}
    if #native==16 then
        local dx,dy,dz=native[14]-position.X,native[15]-position.Y,native[16]-position.Z
        if dx*dx+dy*dy+dz*dz<=420^2 then
            pivot={X=native[14],Y=native[15],Z=native[16]+half*.1}
        end
    end
    local desired={X=native[5],Y=native[6],Z=native[7]}
    local offset={X=desired.X-pivot.X,Y=desired.Y-pivot.Y,Z=desired.Z-pivot.Z}
    local fullDistance=math.sqrt(offset.X*offset.X+offset.Y*offset.Y+offset.Z*offset.Z)
    local distance=fullDistance
    local ksl = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local ignored=ownActors(pawn)
    local swept=false
    if fullDistance>.001 then
        local ok,result=pcall(function()
            local hit={}
            local color={R=0,G=0,B=0,A=0}
            local blocked=ksl:SphereTraceSingle(pc,pivot,desired,12,1,false,ignored,0,hit,true,color,color,0)
            if type(blocked)~="boolean" then return false end
            if not blocked then return true end
            local point=hit.Location
            if not point then return false end
            local projection=0
            for _,axis in ipairs({"X","Y","Z"}) do
                local value=point[axis]
                if type(value)~="number" or value~=value or math.abs(value)>1e8 then return false end
                projection=projection+(value-pivot[axis])*offset[axis]/fullDistance
            end
            distance=math.max(0,math.min(fullDistance,projection-2))
            return true
        end)
        swept=ok and result==true
    end
    local steps=math.max(1,math.min(48,math.ceil(fullDistance/16)))
    for step=1,swept and 0 or steps do
        local d=fullDistance*step/steps
        local fraction=step/steps
        local probe={X=pivot.X+offset.X*fraction,Y=pivot.Y+offset.Y*fraction,Z=pivot.Z+offset.Z*fraction}
        local components = {}
        local ok = pcall(function() ksl:BoxOverlapComponents(pawn, probe, {X=12,Y=12,Z=12}, {0,1,2,3,4,5,6,7}, nil, ignored, components) end)
        if ok then
            local blocked = false
            for _, component in ipairs(components) do
                component=unwrap(component)
                local good, response = pcall(function() return component:GetCollisionResponseToChannel(4) end)
                if good and response == 2 then blocked = true break end
            end
            if blocked then distance = math.max(0,d-24) break end
        end
    end
    local fraction=fullDistance>.001 and math.min(1,distance/fullDistance) or 1
    if ticks%30==0 then write("sa_host.camera_debug",string.format("frame=%d epoch=%d native_distance=%.2f applied_distance=%.2f pivot=%.2f %.2f %.2f desired=%.2f %.2f %.2f",native[3],movementEpoch,fullDistance,distance,pivot.X,pivot.Y,pivot.Z,desired.X,desired.Y,desired.Z)) end
    cameraActor:K2_TeleportTo({X=pivot.X+offset.X*fraction,Y=pivot.Y+offset.Y*fraction,Z=pivot.Z+offset.Z*fraction},
        {Pitch=native[8],Yaw=native[9],Roll=native[10]})
    cameraActor.CameraComponent.FieldOfView=native[11]
    if not lookOwned then pc:SetIgnoreLookInput(true) lookOwned=true end
    local target=pc:GetViewTarget()
    if not ownsView then originalView=target end
    if not ownsView or not valid(target) or target:GetAddress()~=cameraActor:GetAddress() then
        pc:SetViewTargetWithBlend(cameraActor,0,0,0,false)
        ownsView=true
    end
    pawn:SetActorHiddenInGame(true)
    pcall(function()
        local cursor=unwrap(pawn.m_pCursor)
        if valid(cursor) then
            if not hiddenCursor then hiddenCursor={widget=cursor,visibility=cursor:GetVisibility()} end
            cursor:SetVisibility(2)
        end
    end)
    write("sa_view.txt",string.format("1 %d %d %.3f\n",aim and 1 or 0,vehicle and 1 or 0,distance))
    return true
end
local function tick()
    ticks = ticks + 1
    if not playSessionActive() then
        if hadPlaySession then inactive("play session ended") cjMode=false cameraSync=false write("sa_world.enabled","0\n") end
        hadPlaySession=false
        return
    end
    if not hadPlaySession then
        local baseline=io.open("sa_toggle.request","r")
        if baseline then lastToggleSerial=tonumber(baseline:read("*a")) baseline:close() end
    end
    hadPlaySession=true
    local pc = controller()
    if not pc then inactive("controller unavailable") return end
    local pawn = pc.Pawn
    if pawn:GetFullName():find("/Game/Maps/Start.Start", 1, true) then inactive("main menu") return end
    local labActive=labRequest(pawn)
    local request=io.open("sa_toggle.request","r")
    if request then
        local serial=tonumber(request:read("*a")) request:close()
        if serial and (not lastToggleSerial or serial>lastToggleSerial) then
            lastToggleSerial=serial
            if labActive then write("sa_lab.enabled","0\n") end
            toggleCJ()
        end
    end
    if not enabled then inactive("layer disabled") return end
    local gs = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    hostClockTick(pc)
    local paused=gs:IsGamePaused(pc)
    local menu=cjMode and hostMenuVisible(pc,paused)
    windowCollisionTick(cjMode and moveOwned)
    shotTick(pc,pawn,cjMode and moveOwned and not paused and not menu)
    barrierTick(cjMode and moveOwned,pawn)
    if ticks%4==0 then pcall(function()
        write("sa_host.ui",string.format("%d %d %d %d %d\n",cjMode and 1 or 0,moveOwned and 1 or 0,
            pawn:GetState(),pawn.m_pCursor:GetVisibility(),(paused or menu) and 1 or 0))
    end) end
    if paused or menu then
        if nativeFadeOwned then pcall(function() pc.PlayerCameraManager:SetManualCameraFade(0,{R=0,G=0,B=0,A=1},false) end) nativeFadeOwned=false end
        if labActive then gs:SetGamePaused(pc,false)
        elseif cjMode and moveOwned then
            if paused and menu then gs:SetGamePaused(pc,false) end
            -- A host menu suspends input, not the collision/ownership handshake.
            local p=pawn:K2_GetActorLocation()
            local half=pawn.CapsuleComponent:GetScaledCapsuleHalfHeight()
            publishGround(pawn,p,half)
            playerState(false,p,half)
            write("sa_host.menu","1\n")
            -- Hide both guest geometry and HUD behind the host's menu blur, without releasing physics.
            write("sa_host.txt","0\n")
            write("sa_host.reason","paused: native ownership retained")
            return
        else inactive("paused") return end
    end
    write("sa_host.menu","0\n")
    if not frameTargetApplied then
        frameTargetApplied=true
        local ok,err=pcall(function()
            local defaults=StaticFindObject("/Script/Engine.Default__GameUserSettings")
            local settings=defaults:GetGameUserSettings()
            settings:SetVSyncEnabled(false)
            settings:SetFrameRateLimit(60)
            settings:ApplyNonResolutionSettings()
            settings:SaveSettings()
            local ksl=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            ksl:ExecuteConsoleCommand(pc,"t.MaxFPS 60",pc)
            ksl:ExecuteConsoleCommand(pc,"r.VSync 0",pc)
        end)
        print("[SANeighbor] host render target60: "..(ok and "settings applied" or tostring(err)).."\n")
    end
    local cutOk, cutscene = pcall(function() return pawn:IsPlayCutScene() end)
    if cutOk and cutscene then inactive("story cutscene") return end
    if pawnAddress ~= pawn:GetAddress() then
        restoreView()
        cameraActor = nil
        currentPc, currentPawn = pc, pawn
        pawnAddress = pawn:GetAddress()
        pcall(function()
            local lines={}
            local count=0
            for _,actor in ipairs(FindAllOf("Actor") or {}) do
                local name=actor:GetFullName()
                local lower=name:lower()
                if count<32 and (lower:find("sky",1,true) or lower:find("sun",1,true) or lower:find("directionallight",1,true)) then
                    count=count+1 lines[#lines+1]=name
                    pcall(function()
                        local r=actor:K2_GetActorRotation()
                        lines[#lines+1]=string.format("rotation %.3f %.3f %.3f",r.Pitch,r.Yaw,r.Roll)
                    end)
                    local class=actor:GetClass()
                    for depth=1,4 do
                        if not valid(class) then break end
                        class:ForEachProperty(function(prop)
                            local kind=prop:GetClass():GetFName():ToString()
                            if kind=="FloatProperty" or kind=="IntProperty" or kind=="BoolProperty" or kind=="ByteProperty" then
                                local key=prop:GetFName():ToString()
                                pcall(function() lines[#lines+1]=key.."="..tostring(actor[key]) end)
                            end
                        end)
                        class=class:GetSuperStruct()
                        if class:GetFullName():find("/Script/Engine.Actor",1,true) then break end
                    end
                end
            end
            for _,enumName in ipairs({"/Script/HelloNeighbor.EDayMode"}) do
                local enum=StaticFindObject(enumName)
                if valid(enum) then pcall(function()
                    enum:ForEachName(function(name,value) lines[#lines+1]=name:ToString().."="..tostring(value) end)
                end) end
            end
            write("sa_host.time_scene",table.concat(lines,"\n"))
        end)
        pcall(function()
            local lines={}
            local objects={pawn,pc,StaticFindObject("/Engine/Transient.GameEngine_0").GameInstance}
            pcall(function() objects[#objects+1]=gs:GetGameMode(pc) end)
            pcall(function() objects[#objects+1]=gs:GetGameState(pc) end)
            for _,object in ipairs(objects) do
                local class=object:GetClass()
                for depth=1,8 do
                    if not valid(class) or class:GetFullName():find("/Script/Engine.",1,true) then break end
                    lines[#lines+1]=class:GetFullName()
                    class:ForEachProperty(function(prop)
                        local key=prop:GetFName():ToString()
                        if key:lower():find("act",1,true) or key:lower():find("day",1,true) or key:lower():find("time",1,true) then
                            pcall(function() lines[#lines+1]="property "..key.."="..tostring(object[key]) end)
                        end
                    end)
                    class:ForEachFunction(function(fn)
                        local args={}
                        fn:ForEachProperty(function(prop)
                            args[#args+1]=prop:GetFName():ToString()..":"..prop:GetClass():GetFName():ToString()
                        end)
                        lines[#lines+1]=fn:GetFName():ToString().."("..table.concat(args,",")..")"
                    end)
                    class=class:GetSuperStruct()
                end
            end
            write("sa_host.player_api",table.concat(lines,"\n"))
        end)
        print("[SANeighbor] native host player: " .. pawn:GetFullName() .. "\n")
    end
    local position = pawn:K2_GetActorLocation()
    position=pawn:K2_GetActorLocation()
    local half = 75.6
    pcall(function() half = pawn.CapsuleComponent:GetScaledCapsuleHalfHeight() end)
    if cjMode then
        local life=io.open("sa_guest.life","r")
        local available,stamp,dead=nil,nil,nil
        local fade,sourceFresh=0,nil
        if life then
            local text=life:read("*a") life:close()
            local alpha,source
            available,stamp,dead,alpha,source=text:match("^(%d+) (%d+) (%d+)%s*(%d*)%s*(%d*)%s*$")
            available,stamp,dead=tonumber(available),tonumber(stamp),tonumber(dead)
            fade=math.max(0,math.min(255,tonumber(alpha) or 0))
            sourceFresh=tonumber(source)
        end
        local fresh=available==1 and stamp and math.abs(os.time()-stamp)<=2
        local fadeFresh=stamp and math.abs(os.time()-stamp)<=2 and (sourceFresh==1 or (sourceFresh==nil and fresh))
        if fadeFresh and (moveOwned or awaitingRespawn) then
            pcall(function() pc.PlayerCameraManager:SetManualCameraFade(fade/255,{R=0,G=0,B=0,A=1},false) end)
            nativeFadeOwned=fade>0
        elseif nativeFadeOwned then
            pcall(function() pc.PlayerCameraManager:SetManualCameraFade(0,{R=0,G=0,B=0,A=1},false) end)
            nativeFadeOwned=false
        end
        if fresh and dead==0 and moveOwned and not deathAt and not awaitingRespawn then deathArmed=true end
        if fresh and dead==1 and deathArmed and moveOwned and not deathAt then
            awaitingRespawn=true
        end
        if fresh and dead==0 and fade==0 and deathArmed and awaitingRespawn and moveOwned and not deathAt then
            deathArmed=false
            awaitingRespawn=false
            deathAt=ticks deathPawn=pawn:GetAddress()
        end
        if deathAt then
            playerState(false,position,half)
            publishGround(pawn,position,half)
            write("sa_host.txt","0\n")
            write("sa_host.reason","native respawn: host fall")
            if ticks>=deathAt then
                local samePawn=deathPawn==pawn:GetAddress()
                deathAt,deathPawn=nil,nil
                cjMode=false
                restoreView(true)
                write("sa_player.txt","0\n") write("sa_world.enabled","0\n")
                if samePawn then
                    -- Let the game's own landing handler decide the fall outcome.
                    local ok,err=pcall(function()
                        pawn:K2_TeleportTo({X=position.X,Y=position.Y,Z=position.Z+200},pc:GetControlRotation())
                        pawn:LaunchCharacter({X=0,Y=0,Z=-6000},true,true)
                    end)
                    write("sa_host.death",ok and "host fall requested\n" or tostring(err))
                end
            end
            return
        end
    else deathArmed=false awaitingRespawn=false end
    local reply=cjMode and guestReady() or nil
    if cjMode and not reply then
        if moveOwned then
            restoreView(true)
            movementEpoch=movementEpoch+1 moveOrigin=nil nativeSequence=nil sentCorrection=0
            correction={X=0,Y=0,Z=0}
        end
        publishGround(pawn,position,half)
        playerState(false,position,half)
        write("sa_host.txt","0\n") write("sa_host.reason","guest unavailable")
        return
    end
    if reply then position=nativeMovement(pc,pawn,half,reply) end
    pcall(function() half=pawn.CapsuleComponent:GetScaledCapsuleHalfHeight() end)
    if cjMode then publishGround(pawn,position,half) end
    if cjMode and sentCorrection==0 then sentCorrection=ticks end
    playerState(true, position, half, pawn:GetVelocity())
    if reply and moveOwned then
        if not nativeView(pc,pawn,position,half,reply) then restoreView(true,true) end
    else restoreView(true) end
    if ticks%30==0 then
        write("sa_host.state",string.format("%d %d %d %.3f %.3f %.3f\n",cjMode and 1 or 0,
            moveOwned and 1 or 0,pawn.CharacterMovement.MovementMode,position.X,position.Y,position.Z))
    end
    publishCamera(pc)
    write("sa_host.txt", string.format("1 %d %.5f %.5f %.5f\n", ticks, position.X, position.Y, position.Z - half))
    write("sa_host.reason","active")
end
toggleCJ=function()
        if not playSessionActive() then return end
        if deathAt then return end
        deathArmed=false
        awaitingRespawn=false
        if nativeFadeOwned and valid(currentPc) then pcall(function() currentPc.PlayerCameraManager:SetManualCameraFade(0,{R=0,G=0,B=0,A=1},false) end) end
        nativeFadeOwned=false
        mantleUntil,mantleBase,jumpWasDown=-100,nil,false
        cjMode=not cjMode
        lastGuestReply=nil groundContact=nil
        nativeCameraReply=nil nativeCameraTick=-100
        nativeCameraFrame,nativeCameraPid=nil,nil
        movementEpoch=movementEpoch+1
        correction={X=0,Y=0,Z=0} sentCorrection=0 nativeSequence=nil moveOrigin=nil
        enabled=true
        cameraSync=false
        cameraDistance=320
        groundSample=nil groundTick=-100
        write("sa_world.enabled",cjMode and "1\n" or "0\n")
        write("sa_camera.enabled","0\n")
        if not cjMode then restoreView(true) write("sa_player.txt","0\n") end
        print("[SANeighbor] F5 native CJ mode " .. (cjMode and "on" or "off") .. "\n")
end
RegisterKeyBind(Key.F9, function()
    if not playSessionActive() then return end
    if deathAt then return end
    enabled = not enabled
    write("sa_world.enabled", enabled and "1\n" or "0\n")
    if not enabled then write("sa_host.txt", "0\n") end
    print("[SANeighbor] live layer " .. (enabled and "on" or "off") .. "\n")
end)
RegisterKeyBind(Key.F10, function()
    if not playSessionActive() then return end
    write("sa_world.anchor", tostring(ticks) .. "\n")
end)
RegisterKeyBind(Key.F11, function()
    if not playSessionActive() then return end
    if cjMode then return end
    cameraSync = not cameraSync
    write("sa_camera.enabled", cameraSync and "1\n" or "0\n")
    print("[SANeighbor] native GTA camera sync " .. (cameraSync and "on" or "off") .. "\n")
end)
RegisterLoadMapPreHook(function()
    neighborHits={} windowDebris={}
    shotClass=nil shotPid=nil shotSerial=0
    shotExpiries={}
    write("sa_host.clock","0\n")
    if nativeFadeOwned and valid(currentPc) then pcall(function() currentPc.PlayerCameraManager:SetManualCameraFade(0,{R=0,G=0,B=0,A=1},false) end) end
    nativeFadeOwned=false
    deathArmed,deathAt,deathPawn=false,nil,nil
    awaitingRespawn=false
    restoreView(true)
    lastGuestReply=nil groundContact=nil
    nativeCameraReply=nil nativeCameraTick=-100
    nativeCameraFrame,nativeCameraPid=nil,nil
    cjMode, cameraSync = false, false
    waitingForGround=false
    moveOrigin=nil nativeSequence=nil sentCorrection=0 correction={X=0,Y=0,Z=0}
    cameraActor, currentPc, currentPawn = nil, nil, nil
    write("sa_player.txt", "0\n")
    write("sa_camera.enabled", "0\n")
    write("sa_world.enabled", "0\n")
    published, pawnAddress = nil, nil
    write("sa_host.txt", "0\n")
    write("hn_camera.txt", "0 0 0 0 0\n")
end)
LoopAsync(8, function()
    if queued then return false end
    queued = true
    ExecuteInGameThread(function()
        local ok, err = pcall(tick)
        queued = false
        if not ok then
            restoreView(true)
            cjMode=false moveOrigin=nil nativeSequence=nil
            write("sa_world.enabled","0\n") write("sa_camera.enabled","0\n")
            playerState(false)
            failures = failures + 1
            if failures <= 3 or failures % 120 == 0 then print("[SANeighbor] " .. tostring(err) .. "\n") end
            write("sa_host.txt", "0\n")
        end
    end)
    return false
end)
write("sa_player.txt", "0\n")
print("[SANeighbor] F5 toggles native CJ; no converted avatar\n")
