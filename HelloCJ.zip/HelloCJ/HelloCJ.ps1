param([ValidateSet('Install','Play','Stop','Check','Plan','PrepareBat')][string]$Action='Check')
$ErrorActionPreference='Stop'
try {
    . (Join-Path $PSScriptRoot '.tools\ProcessIdentity.ps1')
    $config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw | ConvertFrom-Json
    $gta=[IO.Path]::GetFullPath($config.gtaDir).TrimEnd('\')
    $hn=[IO.Path]::GetFullPath($config.helloNeighborDir).TrimEnd('\')
    $bin=Join-Path $hn 'HelloNeighbor\Binaries\Win64'
    $guestFiles=Join-Path $PSScriptRoot 'files\GTA San Andreas'
    $hostFiles=Join-Path $PSScriptRoot 'files\Hello Neighbor\HelloNeighbor\Binaries\Win64'
    $bridgePath=Join-Path $bin 'sa_live_bridge.exe'
    function Exact([string]$name,[string]$path){
        $items=@(Get-Process -Name $name -ErrorAction SilentlyContinue)
        foreach($item in $items){if((Get-HelloCJProcessPath $item) -ne $path){throw "Cannot verify $name installation; no process changed."}}
        if($items.Count -gt 1){throw "Multiple $name processes; no process changed."}
        $items
    }
    function Admin {
        $p=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    function File-Map([string]$root,[string]$manifest){
        $map=@{}
        if(Test-Path -LiteralPath $manifest){$records=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json;foreach($entry in $records){
            $path=[IO.Path]::GetFullPath((Join-Path $root $entry.path))
            if(-not $path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Installed manifest leaves its game directory.'}
            $map[$path]=$entry.sha256
        }}
        return $map
    }
    if($Action -eq 'Stop'){
        $running=@(Get-Process -Name gta_sa,HelloNeighbor-Win64-Shipping,sa_live_bridge -ErrorAction SilentlyContinue)
        if(-not $running.Count){Write-Host 'Games and mod bridge are already stopped.';exit 0}
        if(-not (Admin)){
            $stopProcess=Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -Wait -PassThru -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-Action','Stop'
            if($stopProcess.ExitCode -ne 0){throw 'Stop failed or administrator request was cancelled. See logs\last-error.txt.'}
            exit 0
        }
        $hostGame=@(Exact 'HelloNeighbor-Win64-Shipping' (Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe'))
        $guest=@(Exact 'gta_sa' (Join-Path $gta 'gta_sa.exe'))
        if(Test-Path -LiteralPath $bin){Set-Content -LiteralPath (Join-Path $bin 'sa_bridge.stop') '1'}
        foreach($p in @($hostGame)+@($guest)){
            $p.CloseMainWindow() | Out-Null
            if(-not $p.WaitForExit(5000)){Stop-Process -Id $p.Id -ErrorAction Stop;$p.WaitForExit()}
        }
        foreach($p in @(Get-Process sa_live_bridge -ErrorAction SilentlyContinue)){
            if($p.Path -eq $bridgePath -and -not $p.WaitForExit(3000)){Stop-Process -Id $p.Id}
        }
        Write-Host 'Configured games stopped. Other applications were not stopped.'
        exit 0
    }
    foreach($file in @((Join-Path $gta 'gta_sa.exe'),(Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe'))){if(-not (Test-Path -LiteralPath $file -PathType Leaf)){throw "Game not found: $file. Edit config.json."}}
    $list=Get-Content -LiteralPath (Join-Path $PSScriptRoot '.tools\files-manifest.json') -Raw | ConvertFrom-Json
    foreach($entry in $list){
        $path=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot $entry.path))
        if(-not $path.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Package manifest path leaves HelloCJ.'}
        if((Get-FileHash -LiteralPath $path).Hash -ne $entry.sha256){throw "Package file changed: $($entry.path)"}
    }
    if($Action -eq 'Check'){Write-Host 'PASS: game paths and local mod files verified. No games started, stopped or installed.';exit 0}
    if($Action -eq 'Play'){
        New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'logs') -Force | Out-Null
        $launchLog=Join-Path $PSScriptRoot 'logs\play.log'
        function Launch-Stage([string]$Message){
            ('{0:o} {1}' -f [DateTime]::UtcNow,$Message) | Add-Content -LiteralPath $launchLog
            Write-Host $Message
        }
        Launch-Stage 'Checking installed files and running games...'
        if(Admin){throw 'Run play.bat normally, not as administrator.'}
        $launchLock=[Threading.Mutex]::new($false,'Local\HelloCJ_PlayLauncher')
        $locked=$false
        try{$locked=$launchLock.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true}
        if(-not $locked){$launchLock.Dispose();throw 'Another play.bat is already preparing the games. Wait for that window; no duplicate games started.'}
        $outdated=@()
        foreach($pair in @(
            @((Join-Path $gta 'd3d9.dll'),(Join-Path $guestFiles 'd3d9.dll')),
            @((Join-Path $gta 'HelloCJAutoStart.asi'),(Join-Path $guestFiles 'HelloCJAutoStart.asi')),
            @((Join-Path $gta 'CLEO\HelloCJIntro.cs'),(Join-Path $guestFiles 'CLEO\HelloCJIntro.cs')),
            @((Join-Path $bin 'ue4ss\Mods\SANeighbor\Scripts\main.lua'),(Join-Path $hostFiles 'ue4ss\Mods\SANeighbor\Scripts\main.lua')),
            @((Join-Path $bin 'ue4ss\Mods\SARenderer\dlls\main.dll'),(Join-Path $hostFiles 'ue4ss\Mods\SARenderer\dlls\main.dll')),
            @($bridgePath,(Join-Path $hostFiles 'sa_live_bridge.exe'))
        )){if(-not (Test-Path -LiteralPath $pair[0]) -or (Get-FileHash -LiteralPath $pair[0]).Hash -ne (Get-FileHash -LiteralPath $pair[1]).Hash){$outdated+=$pair[0]}}
        if($outdated.Count){throw ("The package was updated, but these installed files are missing/outdated:`n"+($outdated -join "`n")+"`nClose both games, run install.bat as administrator, then play.bat normally. No game started.")}
        # StartGuest verifies the elevated GTA path before launch/window changes.
        $hostGame=@(Exact 'HelloNeighbor-Win64-Shipping' (Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe'))
        $bridges=@(Exact 'sa_live_bridge' $bridgePath)
        if(-not $hostGame.Count){
            . (Join-Path $PSScriptRoot '.tools\HostMode.ps1')
            Set-ExclusiveHostMode -Target $bin -Mode SANeighbor
        }
        if(-not $bridges.Count){
                $stop=Join-Path $bin 'sa_bridge.stop'
                if(Test-Path -LiteralPath $stop){Remove-Item -LiteralPath $stop}
                foreach($name in @('sa_host.txt','sa_world.enabled','sa_player.txt','sa_camera.enabled')){Set-Content -LiteralPath (Join-Path $bin $name) '0'}
                foreach($name in @('sa_guest.life','sa_player.ready','sa_play.session','sa_play.hostpid')){if(Test-Path -LiteralPath (Join-Path $bin $name)){Remove-Item -LiteralPath (Join-Path $bin $name)}}
                New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'logs') -Force | Out-Null
                $p=Start-Process -FilePath $bridgePath -ArgumentList ('"'+$bin+'"'),'--play-session' -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'logs\bridge.log') -RedirectStandardError (Join-Path $PSScriptRoot 'logs\bridge-error.log')
                $bridgeStartedHere=$true
                Start-Sleep -Milliseconds 500
                if($p.HasExited){throw 'Bridge failed. See logs\bridge-error.log.'}
        }
        Launch-Stage 'Starting GTA first. Approve the Windows UAC prompt.'
        $guestHelper=Join-Path $PSScriptRoot '.tools\StartGuest.ps1'
        $guestProcess=Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -PassThru -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$guestHelper+'"'),'-GtaDir',('"'+$gta+'"'),'-HostExe',('"'+(Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe')+'"')
        # Wait for the helper only, not its still-running GTA descendant.
        $guestProcess.WaitForExit()
        if($guestProcess.ExitCode -ne 0){
            $reason=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'logs\guest-launch-error.txt') -TotalCount 1 -ErrorAction SilentlyContinue
            throw ("GTA setup failed; Hello Neighbor was not started. $reason See logs\guest-launch-error.txt.")
        }
        Launch-Stage 'Waiting for GTA gameplay, three updating snapshots and completed fade...'
        . (Join-Path $PSScriptRoot '.tools\GuestReady.ps1')
        Wait-HelloCJGuestReady -HostBin $bin
        $hostGame=@(Exact 'HelloNeighbor-Win64-Shipping' (Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe'))
        if(-not $hostGame.Count){
            Launch-Stage 'GTA loaded. Starting Hello Neighbor...'
            $width=1920;$height=1080
            if($null -ne $config.hostWidth){$width=[int]$config.hostWidth}
            if($null -ne $config.hostHeight){$height=[int]$config.hostHeight}
            if($width -lt 640 -or $width -gt 7680 -or $height -lt 480 -or $height -gt 4320){throw 'Invalid hostWidth/hostHeight in config.json.'}
            $hostStarted=Start-Process -FilePath (Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe') -WorkingDirectory $bin -ArgumentList '-windowed',("-ResX="+$width),("-ResY="+$height),'-nosplash','-nostartupmovies' -WindowStyle Normal -PassThru
            Launch-Stage ("Hello Neighbor process started: PID "+$hostStarted.Id)
            Set-Content -LiteralPath (Join-Path $bin 'sa_play.hostpid') $hostStarted.Id
        }else{
            Set-Content -LiteralPath (Join-Path $bin 'sa_play.hostpid') $hostGame[0].Id
        }
        Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class HelloCJForeground {
 [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr w,int command);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr w);
}
'@
        $until=[DateTime]::UtcNow.AddSeconds(60)
        do {
            if($hostStarted -and $hostStarted.HasExited){throw ("Hello Neighbor exited before opening its window. Exit code: "+$hostStarted.ExitCode+". See ue4ss\UE4SS.log in the game folder.")}
            $hostGame=@(Exact 'HelloNeighbor-Win64-Shipping' (Join-Path $bin 'HelloNeighbor-Win64-Shipping.exe'))
            if($hostGame.Count -and $hostGame[0].MainWindowHandle -ne [IntPtr]::Zero){break}
            if([DateTime]::UtcNow -ge $until){throw 'Hello Neighbor did not expose its window.'}
            Start-Sleep -Milliseconds 250
        } while($true)
        [HelloCJForeground]::ShowWindowAsync($hostGame[0].MainWindowHandle,9) | Out-Null
        [HelloCJForeground]::SetForegroundWindow($hostGame[0].MainWindowHandle) | Out-Null
        Launch-Stage 'Games started. GTA window hidden; Hello Neighbor is the main window.'
        exit 0
    }
    $runningGames=@(Get-Process gta_sa,HelloNeighbor-Win64-Shipping -ErrorAction SilentlyContinue)
    if($runningGames.Count -and $Action -ne 'Plan'){
        $details=($runningGames | ForEach-Object {"$($_.ProcessName) (PID $($_.Id))"}) -join ', '
        throw "Close the running games first: $details. No game was stopped."
    }
    $maintenanceBridges=@()
    if($Action -ne 'Plan'){$maintenanceBridges=@(Get-Process sa_live_bridge,cj_bridge,sa_bridge -ErrorAction SilentlyContinue)}
    foreach($process in $maintenanceBridges){
        if(-not $process.Path){throw "Cannot verify bridge $($process.ProcessName) (PID $($process.Id)). Close it in Task Manager."}
        if(-not [string]::Equals($process.Path,$bridgePath,[StringComparison]::OrdinalIgnoreCase)){continue}
        Write-Host "Stopping idle mod bridge (PID $($process.Id)); both games are closed."
        Set-Content -LiteralPath (Join-Path $bin 'sa_bridge.stop') '1'
        if(-not $process.WaitForExit(3000)){
            $current=Get-Process -Id $process.Id -ErrorAction SilentlyContinue
            if($current){
                if(-not [string]::Equals($current.Path,$bridgePath,[StringComparison]::OrdinalIgnoreCase)){throw 'Bridge identity changed; no process stopped.'}
                Stop-Process -Id $current.Id -ErrorAction Stop
                if(-not $current.WaitForExit(3000)){throw 'Bridge did not exit.'}
            }
        }
    }
    if(-not (Test-Path -LiteralPath (Join-Path $gta 'modloader') -PathType Container)){throw 'GTA Mod Loader must already be installed.'}
    $guestOwned=File-Map $gta (Join-Path $gta 'SANeighbor-installed.json')
    $skyRoot=Join-Path $gta 'modloader\SANeighborSky'
    $skyOwned=File-Map $skyRoot (Join-Path $skyRoot 'SANeighbor-sky.json')
    foreach($key in $skyOwned.Keys){$guestOwned[$key]=$skyOwned[$key]}
    $hostOwned=File-Map $bin (Join-Path $bin 'SANeighbor-host.json')
    $operations=@()
    foreach($group in @(@{source=$guestFiles;target=$gta;owned=$guestOwned;name='GTA'},@{source=$hostFiles;target=$bin;owned=$hostOwned;name='HN'})){
        foreach($file in Get-ChildItem -LiteralPath $group.source -File -Recurse){
            $relative=$file.FullName.Substring($group.source.Length+1)
            if($file.Name -in @('SANeighbor-installed.json','SANeighbor-host.json','SANeighbor-sky.json')){continue}
            $target=Join-Path $group.target $relative
            if($group.name -eq 'GTA' -and $relative -eq 'HelloCJ-launch.ini' -and (Test-Path -LiteralPath $target)){continue}
            $sharedConfig=$relative -in @('ue4ss\UE4SS-settings.ini','ue4ss\Mods\mods.txt')
            if(Test-Path -LiteralPath $target){
                if($sharedConfig){continue}
                $hash=(Get-FileHash -LiteralPath $target).Hash
                $sourceHash=(Get-FileHash -LiteralPath $file.FullName).Hash
                if($hash -ne $sourceHash -and $relative -ne 'modloader\_ESSENTIALS\Windowed Mode\III.VC.SA.WindowedMode.ini'){
                    if(-not $group.owned.ContainsKey($target) -or $group.owned[$target] -ne $hash){throw "Externally changed or unrelated file preserved: $target"}
                }
            }
            $operations+=@{source=$file.FullName;target=$target;relative=$relative;group=$group.name}
        }
    }
    $generated=Join-Path $PSScriptRoot ('staging\'+[guid]::NewGuid().ToString('N')+'\gta.dat')
    & (Join-Path $PSScriptRoot '.tools\NewSkyData.ps1') -GtaDir $gta -OutputPath $generated
    $skyData=Join-Path $skyRoot 'gta.dat'
    if(Test-Path -LiteralPath $skyData){
        if(-not $guestOwned.ContainsKey($skyData) -or (Get-FileHash -LiteralPath $skyData).Hash -ne $guestOwned[$skyData]){throw 'An externally changed sky gta.dat was preserved.'}
    }
    $operations+=@{source=$generated;target=$skyData;relative='modloader\SANeighborSky\gta.dat';group='GTA'}
    if($Action -eq 'PrepareBat'){
        $stage=Join-Path $PSScriptRoot 'staging'
        $backup=Join-Path $PSScriptRoot ('backups\'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
        $operations+=@{source=(Join-Path $guestFiles 'SANeighbor-installed.json');target=(Join-Path $gta 'SANeighbor-installed.json');relative='SANeighbor-installed.json';group='GTA'}
        $rows=@($operations | ForEach-Object {
            $parts=@((Split-Path $_.source),(Split-Path $_.target),(Split-Path $_.source -Leaf),(Join-Path (Join-Path $backup $_.group) (Split-Path $_.relative)))
            foreach($part in $parts){if($part -match '[|"\r\n]'){throw 'Unsupported installation path.'}}
            $parts -join '|'
        })
        $rows | Set-Content -LiteralPath (Join-Path $stage 'copy-plan.txt') -Encoding OEM
        @($operations) | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'copy-plan.json') -Encoding UTF8
        Write-Host 'Copy plan ready. BAT will back up and copy the files.'
        exit 0
    }
    if($Action -eq 'Plan'){
        Write-Host ("PASS: ownership checks and install plan ({0} files). No game files changed." -f $operations.Count)
        exit 0
    }
    if(-not (Admin)){
        $p=Start-Process powershell.exe -Verb RunAs -WindowStyle Hidden -Wait -PassThru -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-Action','Install'
        if($p.ExitCode -ne 0){throw 'Installation failed. See logs\last-error.txt.'}
        exit 0
    }
    $backup=Join-Path $PSScriptRoot ('backups\'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    foreach($operation in $operations){
        if(Test-Path -LiteralPath $operation.target){
            $saved=Join-Path (Join-Path $backup $operation.group) $operation.relative
            New-Item -ItemType Directory -Path (Split-Path $saved) -Force | Out-Null
            Copy-Item -LiteralPath $operation.target -Destination $saved
        }
        New-Item -ItemType Directory -Path (Split-Path $operation.target) -Force | Out-Null
        Copy-Item -LiteralPath $operation.source -Destination $operation.target -Force
    }
    Copy-Item -LiteralPath (Join-Path $guestFiles 'SANeighbor-installed.json') -Destination (Join-Path $gta 'SANeighbor-installed.json') -Force
    $prefix='modloader\SANeighborSky\'
    @($operations | Where-Object {$_.group -eq 'GTA' -and $_.relative.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)} | ForEach-Object {
        @{path=$_.relative.Substring($prefix.Length);sha256=(Get-FileHash -LiteralPath $_.target).Hash}
    }) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $skyRoot 'SANeighbor-sky.json')
    foreach($operation in $operations | Where-Object {$_.group -eq 'HN'}){$hostOwned[$operation.target]=(Get-FileHash -LiteralPath $operation.target).Hash}
    @($hostOwned.Keys | ForEach-Object {@{path=$_.Substring($bin.Length+1);sha256=$hostOwned[$_]}}) | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $bin 'SANeighbor-host.json')
    . (Join-Path $PSScriptRoot '.tools\HostMode.ps1')
    Set-ExclusiveHostMode -Target $bin -Mode SANeighbor
    Write-Host 'Installed. Run play.bat normally, not as administrator.'
    exit 0
} catch {
    if($launchLog){('FAIL: '+$_.Exception.Message) | Add-Content -LiteralPath $launchLog -ErrorAction SilentlyContinue}
    if($Action -eq 'Play' -and $bridgeStartedHere -and $bin){Set-Content -LiteralPath (Join-Path $bin 'sa_bridge.stop') '1' -ErrorAction SilentlyContinue}
    New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'logs') -Force | Out-Null
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'logs\last-error.txt')
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
