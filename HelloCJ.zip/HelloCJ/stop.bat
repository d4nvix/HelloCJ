@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0HelloCJ.ps1" goto missing
if not exist "%~dp0config.json" goto missing
echo Closing configured games. Unsaved progress may be lost.
echo Administrator approval is requested only when a game or bridge is running.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0HelloCJ.ps1" -Action Stop
if errorlevel 1 (
  echo Stop failed. See logs\last-error.txt.
  pause
  exit /b 1
)
exit /b 0
:missing
echo Missing HelloCJ.ps1 or config.json. Keep stop.bat inside the complete HelloCJ folder.
pause
exit /b 1
